/**
 * Ajax call to show the loading dialog box while saving the data
 */
$j(document).ajaxStart(function() {
    loadingDialog();
});
$j(document).ajaxStop(function() {
    closeLoading();
});

var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};

function deleteAttCode(id)
{
    //Call the ajax function
    //Confirm before delete

    var url='/admin/attendancecodes/json/deleteLogSyncAttendanceCode.json.html?id='+id;
    jQuery.ajax({
        url: url,
        success: function(){

            console.log('Reloading the page');
            window.location='/admin/attendancecodes/displayLogSyncAttCodes.html';
        },
        error: deleteError
    });

}

function deleteDistrictAttCode(id,schoolid)
{
    //Call the ajax function
    //Confirm before delete

    var url='/admin/district/attendancecodes/json/deleteLogSyncAttendanceCode.json.html?id='+id;
    jQuery.ajax({
        url: url,
        success: function(){

            console.log('Reloading the page');
            window.location='/admin/district/attendancecodes/displayDistrictLogSyncAttCodes.html?schoolid='+schoolid;
        },
        error: deleteError
    });

}