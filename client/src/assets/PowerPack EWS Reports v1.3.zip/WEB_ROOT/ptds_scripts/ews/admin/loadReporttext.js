/*
Loading the data display the various option on the
*/

$jq(document).ready(function(){
    var table=$jq('#ewsTbl').DataTable({
        "paging":   false,
        "ordering": false,
        "info":     false,
        dom:'Blfrtip',
      
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            
            {
                extend: 'colvis',
                text: 'Show / hide columns',
                columns: ':not(.noVis)'
            },
            {
                text: 'Make Current Selection',
                action: function ( e, dt, node, config ) {
                  //  alert( 'Button activated' );
                    var allCalls='';
                    $jq('.stuidhidden').each(function(){
                        if(allCalls=='')
                            allCalls=jQuery(this).val();
                        else 
                            allCalls=allCalls+','+jQuery(this).val(); 
                    });
                    $jq('#studSelectList').val($j('#studSelectList').val() + allCalls);
                    $jq('#stform').submit();
                }
            },
            'copyHtml5',
            'csv',
            {extend : 'pdfHtml5',
           
            orientation : 'landscape',
            pageSize : 'LEGAL',
            text : '<i class="fa fa-file-pdf-o">PDF</i>',
            titleAttr : 'PDF'},
            {
                extend: 'csv',
                text: 'Tab',
                selectedOnly:true,
                FileName:"*.txt",
                charset:"utf8"

            },
            {
                text: 'Print',
                action: function ( e, dt, node, config ) {
                    window.print()

                }
            }
            

            
        ]

        
    });

    
    
});