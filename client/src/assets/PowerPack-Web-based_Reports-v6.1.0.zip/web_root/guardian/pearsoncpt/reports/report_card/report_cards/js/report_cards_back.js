'use strict';
cpt.handlebars.setup();
Handlebars.registerHelper('compare', function (lvalue, operator, rvalue, options) {
    var operators, result;
    if (arguments.length < 3) {
        throw new Error('Handlerbars Helper COMPARE needs 2 parameters');
    }
    if (options === undefined) {
        options = rvalue;
        rvalue = operator;
        operator = '===';
    }
    operators = {
        '==': function (l, r) {
            return l === r;
        },
        '===': function (l, r) {
            return l === r;
        },
        '!=': function (l, r) {
            return l !== r;
        },
        '!==': function (l, r) {
            return l !== r;
        },
        '<': function (l, r) {
            return l < r;
        },
        '>': function (l, r) {
            return l > r;
        },
        '<=': function (l, r) {
            return l <= r;
        },
        '>=': function (l, r) {
            return l >= r;
        },
        'typeof': function (l, r) {
            return typeof l === r;
        }
    };
    if (!operators[operator]) {
        throw new Error('Handlerbars Helper COMPARE does not know the operator ' + operator);
    }
    result = operators[operator](lvalue, rvalue);
    if (result) {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});

cpt.handlebars.processTemplates([
    {
        JSONUrl: 'json/header.json.html',
        templates: [
            {
                templateUrl: 'template/mainheader.hbs.html',
                selector: '#header1-'
            },
            {
                templateUrl: 'template/subheader.hbs.html',
                selector: '#header2-'
            },
            {
                templateUrl: 'template/subheader.hbs.html',
                selector: '#header3-'
            },
            {
                templateUrl: 'template/subheader.hbs.html',
                selector: '#header4-'
            },
            {
                templateUrl: 'template/subheader.hbs.html',
                selector: '#header5-'
            },
            {
                templateUrl: 'template/subheader.hbs.html',
                selector: '#header6-'
            },
            {
                templateUrl: 'template/footer1.hbs.html',
                selector: '#footer1-'
            },
            {
                templateUrl: 'template/footer2.hbs.html',
                selector: '#footer2-'
            },
            {
                templateUrl: 'template/footer3.hbs.html',
                selector: '#footer3-'
            },
            {
                templateUrl: 'template/footer4.hbs.html',
                selector: '#footer4-'
            },
            {
                templateUrl: 'template/footer5.hbs.html',
                selector: '#footer5-'
            },
            {
                templateUrl: 'template/footer5.hbs.html',
                selector: '#footer6-'
            }
        ]
    },
    {
        JSONUrl: 'json/grades.json.html',
        templates: [
            {
                templateUrl: 'template/core.hbs.html',
                selector: '#core-'
            },
            {
                templateUrl: 'template/grades.hbs.html',
                selector: '#language-'
            },
            {
                templateUrl: 'template/socialdevelopment.hbs.html',
                selector: '#socialdevelopment-'
            },
            {
                templateUrl: 'template/electives.hbs.html',
                selector: '#electives-'
            },
            {
                templateUrl: 'template/electivescomments.hbs.html',
                selector: '#electivescomments-'
            }
        ]
    },
    {
        JSONUrl: 'json/comments.json.html',
        templates: {
            templateUrl: 'template/comments.hbs.html',
            selector: '#comments-'
        }
    }
]);
