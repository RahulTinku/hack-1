'use strict';
cpt.handlebars.setup();
cpt.handlebars.processTemplates([
    {
        JSONUrl: 'json/studentTranscript.json.html',
        identifier:"ele"
    }
]);