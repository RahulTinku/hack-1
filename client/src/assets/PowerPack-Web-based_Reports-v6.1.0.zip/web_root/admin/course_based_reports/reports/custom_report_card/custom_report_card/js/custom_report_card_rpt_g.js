'use strict';
cpt.handlebars.setup();

(function($, cpt) {
  cpt.dvchs = cpt.dvchs || (function() {
      var conf = cpt.reportConfig;
      var hbs = cpt.handlebars;

      /**
       * Gets the data!
       * @returns {object}
       */
      function getData(dataUrl) {
        return $.getJSON(dataUrl, conf);
      }

      function sortByKey(array, key) {
        if (array) {
          return array.sort(function(a,b) {
            var x = a[key]; var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
          });
        }
        else {
          return array;
        } 
      }

      function findWithAttr(array, attr, value) {
        for(var i = 0; i < array.length; i += 1) {
            if(array[i][attr] === value) {
                return i;
            }
        }
        return -1;
     }

     function findStandards(array, parent, secid, out) {
       
       for (var i = 0; i < array.length; i += 1) {
         if ((array[i].listparent === parent) && (array[i].sectionid === secid)) {
          if (/_E$/g.test(array[i].identifier)) {
            out.push(array[i]);
          }
          
          if (array[i].nchildren > 0) {
            findStandards(array,array[i].identifier,secid,out);
          }
         }
       }
     }

      var groupBy = function(xs, key, sortbykey) {
        return xs.reduce(function(rv,x) {
          (rv[x[key]] = rv[x[key]] || []).push(x);
          return rv;
        }, {});
      };

      function formatStandardSectionGrades(jsonData) {
        for (var std in jsonData) {
          var grades = groupBy(jsonData[std].standardgradesection,'parentstandardid','parent_sortorder');
          var stdgroup = new Array();
          for (var g in grades) {
            var standard = new Object();
            standard.name = grades[g][0].parentname;
            standard.standardid = grades[g][0].parentstandardid
            standard.sortorder = grades[g][0].parent_sortorder;
            standard.hasgrades = "No";
            standard.marks = new Array();
            
            for (var m in grades[g]) {
              //standard.marks.push(grades[g][m]);
              if (grades[g][m].q1percent.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q1grade.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q2percent.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q2grade.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q3percent.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q3grade.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q4percent.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].q4grade.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].y1percent.length > 0) {
                standard.hasgrades = "Yes";
              } else if (grades[g][m].y1grade.length > 0) {
                standard.hasgrades = "Yes";
              }

              if (standard.hasgrades === "Yes") {
                standard.marks.push(grades[g][m]);
              }
            }

            stdgroup.push(standard);
          }
          jsonData[std].rpt = stdgroup;
        }
      }

      function createReportCard() {
        // create heading: student information
		getData(conf.dataSroredGradesUrl).done(function(data) {
            hbs.jsonToTemplate({
                JSONData: data,
                selector: '#grades-'
            });
        });
      }

      return {
        createReportCard: createReportCard
      };
    })();

  cpt.dvchs.createReportCard();
})(jQuery, cpt);
