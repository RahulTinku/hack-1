// CPT Handlebars v1.4.3 - (c) 2014 Pearson Education, Inc., or its affiliate(s). All rights reserved */
'use strict';

//noinspection JSUnusedGlobalSymbols
/**
 * cpt.handlebars
 * @namespace The namespace for the Handlebars processing
 */
cpt.handlebars = {
  /**
   * Creates the spinner div and begins the spinner when ajax calls begin.
   */
  createSpinner: function () {
    /**
     * Adds the spinner div
     */
    if (document.querySelectorAll('#spinner').length === 0) {
      var spinnerDiv = document.createElement('div');
      spinnerDiv.id = 'spinner';
      document.getElementsByTagName('body')[0].appendChild(spinnerDiv);
    }

    /**
     * Configuration for the javascript spinner
     */
    var Spinner = window.Spinner,
      SpinnerOpts = {
        opts: {
          lines: 13, // The number of lines to draw
          length: 7, // The length of each line
          width: 4, // The line thickness
          radius: 10, // The radius of the inner circle
          corners: 1, // Corner roundness (0..1)
          rotate: 0, // The rotation offset
          color: '#000000', // #rgb or #rrggbb
          speed: 1, // Rounds per second
          trail: 60, // Afterglow percentage
          shadow: false, // Whether to render a shadow
          hwaccel: false, // Whether to use hardware acceleration
          className: 'spinner', // The CSS class to assign to the spinner
          zIndex: 2e9, // The z-index (defaults to 2000000000)
          top: 'auto', // Top position relative to parent in px
          left: 'auto' // Left position relative to parent in px
        },
        target: document.getElementById('spinner')
      };

    /**
     * Starts the spinner
     */
    var spinner = new Spinner(SpinnerOpts.opts).spin(SpinnerOpts.target);

    /**
     * Waits for an ajax calls, shows the spinner, hides the report, and sets the body background to grey.
     */
    jQuery(document).ajaxStart(function () {
      if (!spinner) {
        spinner.start();
      }
      jQuery('#spinner').show();
      jQuery('article').css('display', 'none');
      jQuery('body').attr('bgcolor', '#dddddd').css('opacity', '0.5');
    });

    /**
     * Waits for the completion of all ajax calls, hides the spinner, displays the report, and removes the grey
     * background color.
     */
    jQuery(document).ajaxStop(function () {
      jQuery('#spinner').hide();
      jQuery('article').css('display', 'block');
      jQuery('body').attr('bgcolor', '#ffffff').css('opacity', '1');
    });
  },

  /**
   * Applies the data to the template
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {object} config.JSONData The returned results for the JSONData
   * @param {string} config.template The template used in Handlebars
   * @param {string} config.selector The element where the templated will be placed.
   */
  jsonToTemplate: function (config) {
    jQuery.each(config.JSONData, function (key, val) {


        val.showsixterms=false;
        val.showfiveterms=false;
        val.showquarters=false;
        val.showtrimesters=false;
        val.showsemesters=false;

        if(cpt.reportConfig.useTerm=='sixTerms')
            val.showsixterms=true;
        if(cpt.reportConfig.useTerm=='fiveTerms')
            val.showfiveterms=true;
        if(cpt.reportConfig.useTerm=='q')
            val.showquarters=true;
        if(cpt.reportConfig.useTerm=='t')
            val.showtrimesters=true;
        if(cpt.reportConfig.useTerm=='s')
            val.showsemesters=true;

        /*
         Processing the School name and the level information for previous years
         Reports
         Steve Fernandes
         7 August 2017
         */
        if(config.selector=='#heading-')
        {
            if(cpt.reportConfig.runPrevYear=='Y')
            {
                val.schoolname = val.previousSchoolName;
                val.schooladdress = val.previousSchoolAddr;
                val.schoolphone = val.previousSchoolPhn;
                val.schoolcity = val.previousSchoolCity;
                val.schoolstate = val.previousSchoolState;
                val.schoolzip = val.previousSchoolZip;
            }
        }

        if(val.street == '&nbsp;')
            val.street = '';

        if(val.city == '&nbsp;')
            val.city = '';

        if(val.state == '&nbsp;')
            val.state = '';

        if(val.zip == '&nbsp;')
            val.zip = '';

        val.rptLogo = '';
        val.isLogoAvailable = 'No';

        if(val.school_logo != '')
        {
            val.rptLogo = val.school_logo;
            val.isLogoAvailable = 'Yes';
        }
        else if(val.district_logo != '')
        {
            val.rptLogo = val.district_logo;
            val.isLogoAvailable = 'Yes';
        }

        if(config.selector=='#grades-' || config.selector=='#comments-')
        {
            //Processing the grade values

            var arrAllpossibleTerms=val.allPossibleSchoolTerms;
            var arrCourseGradeInfo=Array();
            var allCommentInfo=Array();

            var arrGradeHeaderData=Array();
            var objHeaderdata={};

            objHeaderdata.isheader=1;
            objHeaderdata.csec="Crse-Se";
            objHeaderdata.cName="Course Title";
            objHeaderdata.teacher="Teacher";

            //If citizenship grades are to be printed then we need to append cit to the grades
            if(cpt.reportConfig.printCitizenship ==1)
            {

            }

            //Have seperate array for display
            var arrMapperArray=Array();

            if(arrAllpossibleTerms.length>0)
            {
                for(var i=0;i<arrAllpossibleTerms.length;i++)
                {
                    //If citizenship grades are to be printed then we need to append cit to the grades
                    if(cpt.reportConfig.printCitizenship ==1)
                    {
                        arrGradeHeaderData[i]=arrAllpossibleTerms[i].description +' - Cit';
                    }
                    else
                    {
                        //Do not show citizenship data
                        arrGradeHeaderData[i]=arrAllpossibleTerms[i].description;
                    }

                    arrMapperArray[i]=arrAllpossibleTerms[i].description;
                }
            }
            else
            {
                if(cpt.reportConfig.printCitizenship ==1)
                {
                    //Show citizen ship data
                    arrGradeHeaderData[0]='Q1 - Cit';
                    arrGradeHeaderData[1]='Q2 - Cit';
                    arrGradeHeaderData[2]='Q3 - Cit';
                    arrGradeHeaderData[3]='Q4 - Cit';
                }
                else
                {
                    //mark default term as Q1, Q2,Q3,Q4
                    arrGradeHeaderData[0]='Q1';
                    arrGradeHeaderData[1]='Q2';
                    arrGradeHeaderData[2]='Q3';
                    arrGradeHeaderData[3]='Q4';
                }

                arrMapperArray[0]='Q1';
                arrMapperArray[1]='Q2';
                arrMapperArray[2]='Q3';
                arrMapperArray[3]='Q4';
            }

            objHeaderdata.gradingdata=arrGradeHeaderData;

            //Push header into all data array
            arrCourseGradeInfo.push(objHeaderdata);

            var allCommentdata=val.allStoredComments;
            var allStoredGrades=val.allStoredgrades;

            //Display the distinc courses
            var arrTempDistinctCourses=val.distinctCourses;
            if(arrTempDistinctCourses.length>0)
            {
                var arrUniqueCourseDetails=Array();
                var arrAllreadyAddedToList=Array();
                for(var y=0;y<arrTempDistinctCourses.length;y++)
                {
                    if(typeof arrTempDistinctCourses[y].courseNumber!='undefined')
                    {
                        if(arrAllreadyAddedToList.indexOf(arrTempDistinctCourses[y].courseNumber)>-1)
                        {
                            //console.log('Course Already added to the list so ignore'+arrTempDistinctCourses[y].courseNumber);
                        }
                        else
                        {
                            arrAllreadyAddedToList.push(arrTempDistinctCourses[y].courseNumber);
                            arrUniqueCourseDetails.push(arrTempDistinctCourses[y]);
                        }
                    }
                }

                val.distinctCourses=arrUniqueCourseDetails;
            }

            //For courses info the is header would be 0
            var allCourses=val.distinctCourses;

            if(allCourses.length>0)
            {
                for(var j=0;j<allCourses.length;j++)
                {
                    if(typeof allCourses[j].crsSec !='undefined')
                    {
                        var tempCourseGradeObject={};
                        tempCourseGradeObject.courseName=allCourses[j].courseName;
                        tempCourseGradeObject.teacherName=allCourses[j].teacherName;
                        tempCourseGradeObject.courseSection=allCourses[j].crsSec;

                        var arrTempCourseGrades=Array();

                        var arrTempThisCourseGradeData=Array();
                        for(var n=0;n<allStoredGrades.length;n++)
                        {
                            if(typeof allStoredGrades[n].courseNumber!='undefined')
                            {
                                if(allStoredGrades[n].courseNumber==allCourses[j].courseNumber)
                                {
                                    arrTempThisCourseGradeData.push(allStoredGrades[n]);
                                }
                            }
                        }

                        for(var m=0;m<arrMapperArray.length;m++)
                        {
                            var selectedStoreCode=arrMapperArray[m];
                            arrTempCourseGrades[m]='';
                            for(var t=0;t<arrTempThisCourseGradeData.length;t++)
                            {
                                if(selectedStoreCode==arrTempThisCourseGradeData[t].storeCode)
                                {
                                    if(cpt.reportConfig.printCitizenship ==1)
                                    {
                                        //show the citizenship grade appended to the main grade
                                        if(arrTempCourseGrades[m]!='')
                                        {
                                            if(arrTempThisCourseGradeData[t].behavior != '')
                                                arrTempCourseGrades[m]=arrTempCourseGrades[m]+'<br/>&nbsp;'+arrTempThisCourseGradeData[t].value+' - '+arrTempThisCourseGradeData[t].behavior;
                                            else
                                                arrTempCourseGrades[m]=arrTempCourseGrades[m]+'<br/>&nbsp;'+arrTempThisCourseGradeData[t].value;
                                        }
                                        else
                                        {
                                            if(arrTempThisCourseGradeData[t].behavior != '')
                                                arrTempCourseGrades[m]='&nbsp;'+arrTempThisCourseGradeData[t].value+' - '+arrTempThisCourseGradeData[t].behavior;
                                            else
                                                arrTempCourseGrades[m]='&nbsp;'+arrTempThisCourseGradeData[t].value;
                                        }
                                    }
                                    else
                                    {
                                        if(arrTempCourseGrades[m]!='')
                                            arrTempCourseGrades[m]=arrTempCourseGrades[m]+'<br/>&nbsp;'+arrTempThisCourseGradeData[t].value;
                                        else
                                            arrTempCourseGrades[m]='&nbsp;'+arrTempThisCourseGradeData[t].value;
                                    }
                                }
                            }
                        }

                        tempCourseGradeObject.gradingdata=arrTempCourseGrades;
                        arrCourseGradeInfo.push(tempCourseGradeObject);

                        var tempCommentObject={};
                        //processing the comments firts
                        tempCommentObject.courseName=allCourses[j].courseName;
                        tempCommentObject.teacherName=allCourses[j].teacherName;
                        tempCommentObject.comment='';
                        //Loop through the comment object
                        if(allCommentdata.length>0)
                        {
                            for(var v=0;v<allCommentdata.length;v++)
                            {
                                if(typeof allCommentdata[v].commentValue!='undefined')
                                {
                                    if(allCommentdata[v].course_number==allCourses[j].courseNumber)
                                    {
                                       // console.log('comment belongs to this course');
                                        if(tempCommentObject.comment=='')
                                            tempCommentObject.comment=allCommentdata[v].commentValue;
                                        else
                                            tempCommentObject.comment= tempCommentObject.comment+', '+allCommentdata[v].commentValue;
                                    }
                                }
                            }
                        }

                        if(tempCommentObject.comment!='')
                        {
                            //push value in comment array
                            allCommentInfo.push(tempCommentObject);
                        }
                    }
                }
            }

            //Additional logic to print blank row if there are no comments
            if(allCommentInfo.length==0)
            {
                var tempCommentObject={};
                //processing the comments firts
                tempCommentObject.courseName='';
                tempCommentObject.teacherName='';
                tempCommentObject.comment='';
                allCommentInfo.push(tempCommentObject);
            }

            val.commentData=allCommentInfo;

            val.storedGradeValues=arrCourseGradeInfo;

            /* Handling Attendance Combination based on the New Logic
            Steve Fernandes
            For Absent, we need to consider following attendance code:
            A,AE.AU
            For Tardy we need to consider following attendance codes
            T,TU,TE
             */
            var totalAbsentT1=0;
            var totalAbsentT2=0;
            var totalAbsentT3=0;
            var totalAbsentT4=0;
            var totalAbsentT5=0;
            var totalAbsentT6=0;
            var totalYearlyAbsent=0;

            var t1Abs=val.t1_absent;
            var t2Abs=val.t2_absent;
            var t3Abs=val.t3_absent;
            var t4Abs=val.t4_absent;
            var t5Abs=val.t5_absent;
            var t6Abs=val.t6_absent;

            totalAbsentT1=Number(t1Abs);
            totalAbsentT2=Number(t2Abs);
            totalAbsentT3=Number(t3Abs);
            totalAbsentT4=Number(t4Abs);
            totalAbsentT5=Number(t5Abs);
            totalAbsentT6=Number(t6Abs);

            var totalTardyT1=0;
            var totalTardyT2=0;
            var totalTardyT3=0;
            var totalTardyT4=0;
            var totalTardyT5=0;
            var totalTardyT6=0;
            var totalYearlytardy=0;

            var t1Tar=val.t1_tardy;
            var t2Tar=val.t2_tardy;
            var t3Tar=val.t3_tardy;
            var t4Tar=val.t4_tardy;
            var t5Tar=val.t5_tardy;
            var t6Tar=val.t6_tardy;

            totalTardyT1=Number(t1Tar);
            totalTardyT2=Number(t2Tar);
            totalTardyT3=Number(t3Tar);
            totalTardyT4=Number(t4Tar);
            totalTardyT5=Number(t5Tar);
            totalTardyT6=Number(t6Tar);

            if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term1)
            {
               // console.log('Show T1 attendance Only');
                totalYearlyAbsent=totalAbsentT1;
                totalYearlytardy=totalTardyT1;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=0;
                val.t3_abs=0;
                val.t4_abs=0;
                val.t5_abs=0;
                val.t6_abs=0;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=0;
                val.t3_tar=0;
                val.t4_tar=0;
                val.t5_tar=0;
                val.t6_tar=0;
                val.tot_tar=totalYearlytardy;
            }
            else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term2)
            {
                totalYearlyAbsent=totalAbsentT1+totalAbsentT2;
                totalYearlytardy=totalTardyT1+totalTardyT2;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=totalAbsentT2;
                val.t3_abs=0;
                val.t4_abs=0;
                val.t5_abs=0;
                val.t6_abs=0;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=totalTardyT2;
                val.t3_tar=0;
                val.t4_tar=0;
                val.t5_tar=0;
                val.t6_tar=0;
                val.tot_tar=totalYearlytardy;
            }
            else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term3)
            {
                totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3;
                totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=totalAbsentT2;
                val.t3_abs=totalAbsentT3;
                val.t4_abs=0;
                val.t5_abs=0;
                val.t6_abs=0;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=totalTardyT2;
                val.t3_tar=totalTardyT3;
                val.t4_tar=0;
                val.t5_tar=0;
                val.t6_tar=0;
                val.tot_tar=totalYearlytardy;
            }
            else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term4)
            {
                totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3+totalAbsentT4;
                totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3+totalTardyT4;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=totalAbsentT2;
                val.t3_abs=totalAbsentT3;
                val.t4_abs=totalAbsentT4;
                val.t5_abs=0;
                val.t6_abs=0;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=totalTardyT2;
                val.t3_tar=totalTardyT3;
                val.t4_tar=totalTardyT4;
                val.t5_tar=0;
                val.t6_tar=0;
                val.tot_tar=totalYearlytardy;
            }
            else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term5)
            {
                totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3+totalAbsentT4+totalAbsentT5;
                totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3+totalTardyT4+totalTardyT5;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=totalAbsentT2;
                val.t3_abs=totalAbsentT3;
                val.t4_abs=totalAbsentT4;
                val.t5_abs=totalAbsentT5;
                val.t6_abs=0;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=totalTardyT2;
                val.t3_tar=totalTardyT3;
                val.t4_tar=totalTardyT4;
                val.t5_tar=totalTardyT5;
                val.t6_tar=0;
                val.tot_tar=totalYearlytardy;
            }
            else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term6)
            {
                totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3+totalAbsentT4+totalAbsentT5+totalAbsentT6;
                totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3+totalTardyT4+totalTardyT5+totalTardyT6;

                val.t1_abs=totalAbsentT1;
                val.t2_abs=totalAbsentT2;
                val.t3_abs=totalAbsentT3;
                val.t4_abs=totalAbsentT4;
                val.t5_abs=totalAbsentT5;
                val.t6_abs=totalAbsentT6;
                val.tot_abs=totalYearlyAbsent;

                val.t1_tar=totalTardyT1;
                val.t2_tar=totalTardyT2;
                val.t3_tar=totalTardyT3;
                val.t4_tar=totalTardyT4;
                val.t5_tar=totalTardyT5;
                val.t6_tar=totalTardyT6;
                val.tot_tar=totalYearlytardy;
            }
        }

        val.userid=key.slice(8, key.length);

        var theTemplateScriptSecondPage = jQuery("#print-template-section1").html();
        // Compile the template
        var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
        // Pass our data to the template
        var theCompiledHtmlPage2 = theTemplatePage2(val);

        jQuery('#grades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);

        var theTemplateScriptSecondPage = jQuery("#print-template-section2").html();
        // Compile the template
        var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
        // Pass our data to the template
        var theCompiledHtmlPage2 = theTemplatePage2(val);

        jQuery('#secondPage-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
        // jQuery('#eightPage-'+ key.slice(8, key.length)).show();

        var theTemplateScriptSecondPage = jQuery("#print-template-section3").html();
        // Compile the template
        var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
        // Pass our data to the template
        var theCompiledHtmlPage2 = theTemplatePage2(val);

        jQuery('#thirdPage-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);

        var theTemplateScriptSecondPage = jQuery("#print-template-section4").html();
        // Compile the template
        var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
        // Pass our data to the template
        var theCompiledHtmlPage2 = theTemplatePage2(val);

        jQuery('#fourthPage-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);

        //columnizing the data
        var content_height=800;
        var content_height_other=1500;

        //can put loading symeboll but need assurance that this will fin ..

        if(jQuery('#commentdata-'+key.slice(8, key.length)).contents().length > 0){
            // here is the columnizer magic
            jQuery('#commentdata-'+key.slice(8, key.length)).columnize({
                columns: 1,
                target: "#firstpageComment-"+key.slice(8, key.length),
                overflow: {
                    height: content_height,
                    id: "#commentdata-"+key.slice(8, key.length),
                    doneFunc: function(){
                        //done with page 1 moving to page 2

                        if(jQuery('#commentdata-'+key.slice(8, key.length)).contents().length > 0){
                            // here is the columnizer magic
                            jQuery('#commentdata-'+key.slice(8, key.length)).columnize({
                                columns: 1,
                                target: "#secondPageComment-"+key.slice(8, key.length),
                                overflow: {
                                    height: content_height_other,
                                    id: "#commentdata-"+key.slice(8, key.length),
                                    doneFunc: function(){
                                        //done with page 2 moving to page
                                        if(jQuery('#commentdata-'+key.slice(8, key.length)).contents().length > 0){
                                            // here is the columnizer magic
                                            jQuery('#commentdata-'+key.slice(8, key.length)).columnize({
                                                columns: 1,
                                                target: "#thirdPageComment-"+key.slice(8, key.length),
                                                overflow: {
                                                    height: content_height_other,
                                                    id: "#commentdata-"+key.slice(8, key.length),
                                                    doneFunc: function(){
                                                        //done with page 3 moving to page 4
                                                        if(jQuery('#commentdata-'+key.slice(8, key.length)).contents().length > 0){
                                                            // here is the columnizer magic
                                                            jQuery('#commentdata-'+key.slice(8, key.length)).columnize({
                                                                columns: 1,
                                                                target: "#fourthPageComment-"+key.slice(8, key.length),
                                                                overflow: {
                                                                    height: content_height_other,
                                                                    id: "#commentdata-"+key.slice(8, key.length),
                                                                    doneFunc: function(){
                                                                        //done with page 4 moving to page 5
                                                                    }
                                                                }
                                                            });
                                                        }
                                                        else
                                                        {
                                                            //Close and remove all remaining pages
                                                            removeUnusedPages(4,key);
                                                        }
                                                    }
                                                }
                                            });
                                        }
                                        else
                                        {
                                            //Close and remove all remaining pages
                                            removeUnusedPages(3,key);
                                        }
                                    }
                                }
                            });
                        }
                        else
                        {
                            //Close and remove all remaining pages
                            removeUnusedPages(2,key);
                        }
                    }
                }
            });
        }
        else
        {
            //Close and remove all page
        }
        jQuery(window).resize();
    });
  },

  /**
   * Grab the template file and render it for merging with the data
   * @param {json} config The configuration from the processTemplates JSON configuration
   * @param {string} config.selector The element in which you will be placing the template
   * @param {string} config.template The template loaded with the data
   * @param {json} value The template and selector for this JSON string to be merged.
   * @param {string} value.templateUrl The returned URL For the template file
   * @param {string} value.selector The element returned for placing the rendered template
   */
  getTemplatesAndRender: function (config, value) {
    jQuery.get(value.templateUrl, function (data) {
      config.selector = value.selector;
      config.template = Handlebars.compile(data);
      cpt.handlebars.jsonToTemplate(config);
    });
  },

  /**
   * If the template in the config is a string, process the data once. If it is an array, process it once per listed
   * template.
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {object} config.templates The templates used in the Handlebars template
   */
  processTemplateOrArray: function (config) {
    if (Object.prototype.toString.call(config.templates) === '[object Array]') {
      jQuery.each(config.templates, function (index, value) {
        cpt.handlebars.getTemplatesAndRender(config, value);
      });
    } else if (Object.prototype.toString.call(config.templates) === '[object Object]') {
      cpt.handlebars.getTemplatesAndRender(config, config.templates);
    }
  },

  /**
   * Retrieve the JSON file, pass the reportConfig as post values, and send to process
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {string} config.JSONUrl The URL of the JSON file
   * @param {object} config.JSONData The Data returned from the JSON file
   */
  getJSONData: function (config) {
    jQuery.getJSON(config.JSONUrl, cpt.reportConfig, function (response) {
      config.JSONData = response;
      cpt.handlebars.processTemplateOrArray(config);
    });
  },

  /**
   * Retrieve template information and begin to process.
   * @param {json} section The section of the grouping which is processed.
   */
  processTemplates: function (section) {
    jQuery.each(section, function (index, value) {
      cpt.handlebars.getJSONData(value);
    });
  },

  /**
   * The setup elements which are passed to all pages.
   */
  setup: function () {
    cpt.handlebars.createSpinner();

    /**
     *  For all templates. Forces the numeric value to a fixed decimal place (ie. {{toFixed weighted 4}})
     */
    Handlebars.registerHelper('toFixed', function (object, points) {
      if (object && !isNaN(object)) {
        return parseFloat(object).toFixed(points);
      } else {
        return '';
      }
    });

    /**
     * For all templates, compares 2 values in order to determine whether to print an option
     * (ie. {{compare gradelevel "2"}} or {{compare gradelevel ">=" "2"}})
     */
    Handlebars.registerHelper('compare', function (lvalue, operator, rvalue, options) {
      //noinspection JSUnusedLocalSymbols
      var operators, result;
      if (arguments.length < 3) {
        throw new Error('Handlebars Helper \'compare\' needs 2 parameters');
      }
      if (options === undefined) {
        //noinspection JSUnusedAssignment
        options = rvalue;
        //noinspection JSUnusedAssignment
        rvalue = operator;
        //noinspection JSUnusedAssignment
        operator = '===';
      }
      //noinspection JSUnusedAssignment
      operators = {
        '==': function (l, r) {
          return l === r;
        },
        '===': function (l, r) {
          return l === r;
        },
        '!=': function (l, r) {
          return l !== r;
        },
        '!==': function (l, r) {
          return l !== r;
        },
        '<': function (l, r) {
          return l < r;
        },
        '>': function (l, r) {
          return l > r;
        },
        '<=': function (l, r) {
          return l <= r;
        },
        '>=': function (l, r) {
          return l >= r;
        },
        'typeof': function (l, r) {
          return typeof l === r;
        }
      };
      if (!operators[operator]) {
        throw new Error('Handlebars Helper COMPARE does not know the operator ' + operator);
      }
      result = operators[operator](lvalue, rvalue);
      if (result) {
        return options.fn(this);
      } else {
        return options.inverse(this);
      }
    });

    /**
       * For all templates, if string length > 0
       */
      Handlebars.registerHelper('ifNotEmptyString', function (str, options) {
          if (typeof str !== 'undefined') {
              if (str.length > 0) {
                  return options.fn(this);
              } else {
                  return options.inverse(this);
              }
          } else {
              return options.inverse(this);
          }
      });

      /**
       * For all templates, if string length > 0
       */
      Handlebars.registerHelper('ifNotEmptyStringThreeMultiple', function (str, str2, str3, options) {
          if (typeof str !== 'undefined') {
              if (str.length > 0 || str2.length>0 || str3.length>0) {
                  return options.fn(this);
              } else {
                  return options.inverse(this);
              }
          } else {
              return options.inverse(this);
          }
      });

      /**
       * For all templates, if string length > 0
       */
      Handlebars.registerHelper('ifNotEmptyStringTwoMultiple', function (str, str2, options) {
          if (typeof str !== 'undefined') {
              if (str.length > 0 || str2.length>0) {
                  return options.fn(this);
              } else {
                  return options.inverse(this);
              }
          } else {
              return options.inverse(this);
          }
      });
  },
  /**
   * Merge a json file from a variable into a handlebars external template and load into an element.
   * @param {string} hbs The URL of the handlebars template
   * @param {string} json The URL of the json string
   * @param {string} element The element you are inserting the rendered template into
   */
  loadTemplate: function (hbs, json, element) {
    jQuery.get(hbs, function (source) {
      var template = Handlebars.compile(source);
      jQuery.getJSON(json, function (context) {
        var html;
        if (Object.prototype.toString.call(context) === '[object Array]') {
          context.pop();
        }
        html = template(context);
        jQuery(element).html(html);
      });
    });
  }
};
