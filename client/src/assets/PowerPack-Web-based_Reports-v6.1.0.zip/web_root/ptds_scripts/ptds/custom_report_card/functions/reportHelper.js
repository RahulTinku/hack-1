//Processing data using handle bars
Handlebars.registerHelper('displayGradeData', function(standardArray) {
    var html='';

    for(i=0;i<standardArray.length;i++)
    {
        //check if helper
        if(typeof standardArray[i].isheader!='undefined')
        {
            //processing header row
            html=html+'<tr><th class="box greybkgrd">Crse-Se1</th><th class="box greybkgrd">Course Title</th><th class="box greybkgrd">Teacher</th>';

            var arrDate=standardArray[i].gradingdata;
            for(var j=0;j<arrDate.length;j++)
            {
                html=html+'<th class="box greybkgrd mark">'+arrDate[j]+'</th>';
            }
            html=html+'</tr>';
        }
        else
        {
            //Process Normal date
            //processing header row
            html=html+'<tr><td class="box">'+standardArray[i].courseSection+'</td><td class="box">'+standardArray[i].courseName+'</td><td class="box">'+standardArray[i].teacherName+'</td>';

            var arrDate=standardArray[i].gradingdata;
            for(var j=0;j<arrDate.length;j++)
            {
                html=html+'<td class="box mark" style="text-align: center;">'+arrDate[j]+'</td>';
            }
            html=html+'</tr>';
        }
    }

    return html;
});




