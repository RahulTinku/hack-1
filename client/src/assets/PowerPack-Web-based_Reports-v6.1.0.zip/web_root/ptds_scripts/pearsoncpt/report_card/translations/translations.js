var arrTranslation=new Array();
arrTranslation['reportTitle']='INFORME DE PROGRESO';
arrTranslation['yearDesc']='Año escolar';
arrTranslation['dateDesc']='Fecha';
arrTranslation['gradeDesc']='GRADO';
arrTranslation['kgDesc']='JARDÍN DE INFANCIA';
arrTranslation['phoneDesc']='Teléfono';
arrTranslation['studentNameDesc']='NOMBRE DEL ESTUDIANTE';
arrTranslation['studentNumberDesc']='NÚMERO DE IDENTIFICACIÓN';
arrTranslation['studentHomeroomDesc']='HomeRoom';
arrTranslation['courseContinuedDesc']='Curso Continuado...';
arrTranslation['daysAbsentDesc']='DÍAS AUSENTE';
arrTranslation['daystardyDesc']='TIEMPOS TARDES';
arrTranslation['Comment4header']='Periodo de calificación 4 comentarios.';
arrTranslation['Comment3header']='Periodo de calificación 3 comentarios.';
arrTranslation['Comment2header']='Periodo de calificación 2 comentarios.';
arrTranslation['Comment1header']='Periodo de calificación 1 comentarios.';

