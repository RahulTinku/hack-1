var arrTranslation=new Array();
arrTranslation['reportTitle']='PROGRESS REPORT';
arrTranslation['yearDesc']='School Year';
arrTranslation['dateDesc']='Date';
arrTranslation['gradeDesc']='GRADE';
arrTranslation['kgDesc']='KINDERGARTEN';
arrTranslation['phoneDesc']='Phone';
arrTranslation['studentNameDesc']='STUDENT NAME';
arrTranslation['studentNumberDesc']='ID NUMBER';
arrTranslation['studentHomeroomDesc']='HomeRoom';
arrTranslation['courseContinuedDesc']='Course Continued...';
arrTranslation['daysAbsentDesc']='DAYS ABSENT';
arrTranslation['daystardyDesc']='TIMES TARDY';
arrTranslation['Comment4header']='Marking Period 4 comments';
arrTranslation['Comment3header']='Marking Period 3 comments';
arrTranslation['Comment2header']='Marking Period 2 comments';
arrTranslation['Comment1header']='Marking Period 1 comments';



