// CPT Handlebars v1.4.2 - (c) 2014 Pearson Education, Inc., or its affiliate(s). All rights reserved */
'use strict';

//noinspection JSUnusedGlobalSymbols
/**
 * cpt.handlebars
 * @namespace The namespace for the Handlebars processing
 */
cpt.handlebars = {
    /**
     * Creates the spinner div and begins the spinner when ajax calls begin.
     */
    createSpinner: function () {
        /**
         * Adds the spinner div
         */
        if (document.querySelectorAll('#spinner').length === 0) {
            var spinnerDiv = document.createElement('div');
            spinnerDiv.id = 'spinner';
            document.getElementsByTagName('body')[0].appendChild(spinnerDiv);
        }

        /**
         * Configuration for the javascript spinner
         */
        var Spinner = window.Spinner,
            SpinnerOpts = {
                opts: {
                    lines: 13, // The number of lines to draw
                    length: 7, // The length of each line
                    width: 4, // The line thickness
                    radius: 10, // The radius of the inner circle
                    corners: 1, // Corner roundness (0..1)
                    rotate: 0, // The rotation offset
                    color: '#000000', // #rgb or #rrggbb
                    speed: 1, // Rounds per second
                    trail: 60, // Afterglow percentage
                    shadow: false, // Whether to render a shadow
                    hwaccel: false, // Whether to use hardware acceleration
                    className: 'spinner', // The CSS class to assign to the spinner
                    zIndex: 2e9, // The z-index (defaults to 2000000000)
                    top: 'auto', // Top position relative to parent in px
                    left: 'auto' // Left position relative to parent in px
                },
                target: document.getElementById('spinner')
            };

        /**
         * Starts the spinner
         */
        var spinner = new Spinner(SpinnerOpts.opts).spin(SpinnerOpts.target);

        /**
         * Waits for an ajax calls, shows the spinner, hides the report, and sets the body background to grey.
         */
        jQuery(document).ajaxStart(function () {
            if (!spinner) {
                spinner.start();
            }
            jQuery('#spinner').show();
            jQuery('article').css('display', 'none');
            jQuery('body').attr('bgcolor', '#dddddd').css('opacity', '0.5');
        });

        /**
         * Waits for the completion of all ajax calls, hides the spinner, displays the report, and removes the grey
         * background color.
         */
        jQuery(document).ajaxStop(function () {
            jQuery('#spinner').hide();
            jQuery('article').css('display', 'block');
            jQuery('body').attr('bgcolor', '#ffffff').css('opacity', '1');
        });
    },

    /**
     * Applies the data to the template
     * @param {json} config The configuration from the processTemplates JSON configuration.
     * @param {object} config.JSONData The returned results for the JSONData
     * @param {string} config.template The template used in Handlebars
     * @param {string} config.selector The element where the templated will be placed.
     */
    jsonToTemplate: function (config) {
        jQuery.each(config.JSONData, function (key, val) {

            /*Customizing this for certain selector only*/
            val.showquarters=false;
            val.showtrimesters=false;
            val.showsemesters=false;

            if(cpt.reportConfig.useTerm=='q')
                val.showquarters=true;
            if(cpt.reportConfig.useTerm=='t')
                val.showtrimesters=true;
            if(cpt.reportConfig.useTerm=='s')
                val.showsemesters=true;
            if(config.selector=='#comments-')
            {
                var period4comment=arrTranslation['Comment4header']
                var period3comment=arrTranslation['Comment3header']
                var period2comment=arrTranslation['Comment2header']
                var period1comment=arrTranslation['Comment1header']
                var selectedLanguageheader3=val.lang;

                //Assigning translation
                val.period4comment=period4comment;
                val.period3comment=period3comment;
                val.period2comment=period2comment;
                val.period1comment=period1comment;

                var allCommentarray=Array();
                allCommentarray=val.arrAllCourseStandardData;

                if(allCommentarray.length>1)
                {
                    var ct1='';
                    var ct2='';
                    var ct3='';
                    var ct4='';
                    //Loop through the array and aggregate the comment
                    for(var coml=0;coml<allCommentarray.length;coml++)
                    {
                        if(typeof allCommentarray[coml].ct1!='undefined')
                        {
                            if(allCommentarray[coml].ct1!='' && allCommentarray[coml].ct1!=' ')
                                ct1=ct1+allCommentarray[coml].ct1;
                            if(allCommentarray[coml].ct2!='' && allCommentarray[coml].ct2!=' ')
                                ct2=ct2+allCommentarray[coml].ct2;
                            if(allCommentarray[coml].ct3!='' && allCommentarray[coml].ct3!=' ')
                                ct3=ct3+allCommentarray[coml].ct3;
                            if(allCommentarray[coml].ct4!='' && allCommentarray[coml].ct4!=' ')
                                ct4=ct4+allCommentarray[coml].ct4;
                        }
                    }

                    val.ct1=ct1;
                    val.ct2=ct2;
                    val.ct3=ct3;
                    val.ct4=ct4;
                }
            }

            if(config.selector=='#header1-')
            {
                //Processing the attendance values to whats required for consistency
                // Steve Fernandes
                /* Handling Attendance Combination based on the New Logic
                 Steve Fernandes
                 For Absent, we need to consider following attendance code:
                 A,AE.AU
                 For Tardy we need to consider following attendance codes
                 T,TU,TE
                 */

                var selectedLanguageheader1=val.lang;

                //Assigning translation
                //English translation
                var daysAbsent=arrTranslation['daysAbsentDesc'];
                var daysTardy=arrTranslation['daystardyDesc'];

                val.daysAbsentHeader=daysAbsent;
                val.daysTardyHeader=daysTardy;

                var totalAbsentT1=0;
                var totalAbsentT2=0;
                var totalAbsentT3=0;
                var totalAbsentT4=0;
                var totalYearlyAbsent=0;

                var t1Abs=val.t1_absent;
                var t2Abs=val.t2_absent;
                var t3Abs=val.t3_absent;
                var t4Abs=val.t4_absent;

                totalAbsentT1=Number(t1Abs);
                totalAbsentT2=Number(t2Abs);
                totalAbsentT3=Number(t3Abs);
                totalAbsentT4=Number(t4Abs);

                var totalTardyT1=0;
                var totalTardyT2=0;
                var totalTardyT3=0;
                var totalTardyT4=0;
                var totalYearlytardy=0;

                var t1Tar=val.t1_tardy;
                var t2Tar=val.t2_tardy;
                var t3Tar=val.t3_tardy;
                var t4Tar=val.t4_tardy;

                totalTardyT1=Number(t1Tar);
                totalTardyT2=Number(t2Tar);
                totalTardyT3=Number(t3Tar);
                totalTardyT4=Number(t4Tar);

                if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term1)
                {
                    totalYearlyAbsent=totalAbsentT1;
                    totalYearlytardy=totalTardyT1;

                    val.t1_abs=totalAbsentT1;
                    val.t2_abs=0;
                    val.t3_abs=0;
                    val.t4_abs=0;
                    val.tot_abs=totalYearlyAbsent;

                    val.t1_tar=totalTardyT1;
                    val.t2_tar=0;
                    val.t3_tar=0;
                    val.t4_tar=0;
                    val.tot_tar=totalYearlytardy;
                }
                else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term2)
                {
                    totalYearlyAbsent=totalAbsentT1+totalAbsentT2;
                    totalYearlytardy=totalTardyT1+totalTardyT2;

                    val.t1_abs=totalAbsentT1;
                    val.t2_abs=totalAbsentT2;
                    val.t3_abs=0;
                    val.t4_abs=0;
                    val.tot_abs=totalYearlyAbsent;

                    val.t1_tar=totalTardyT1;
                    val.t2_tar=totalTardyT2;
                    val.t3_tar=0;
                    val.t4_tar=0;
                    val.tot_tar=totalYearlytardy;
                }
                else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term3)
                {
                    totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3;
                    totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3;

                    val.t1_abs=totalAbsentT1;
                    val.t2_abs=totalAbsentT2;
                    val.t3_abs=totalAbsentT3;
                    val.t4_abs=0;
                    val.tot_abs=totalYearlyAbsent;

                    val.t1_tar=totalTardyT1;
                    val.t2_tar=totalTardyT2;
                    val.t3_tar=totalTardyT3;
                    val.t4_tar=0;
                    val.tot_tar=totalYearlytardy;
                }
                else if(cpt.reportConfig.selectedStoreCode==cpt.reportConfig.term4)
                {
                    totalYearlyAbsent=totalAbsentT1+totalAbsentT2+totalAbsentT3+totalAbsentT4;
                    totalYearlytardy=totalTardyT1+totalTardyT2+totalTardyT3+totalTardyT4;

                    val.t1_abs=totalAbsentT1;
                    val.t2_abs=totalAbsentT2;
                    val.t3_abs=totalAbsentT3;
                    val.t4_abs=totalAbsentT4;
                    val.tot_abs=totalYearlyAbsent;

                    val.t1_tar=totalTardyT1;
                    val.t2_tar=totalTardyT2;
                    val.t3_tar=totalTardyT3;
                    val.t4_tar=totalTardyT4;
                    val.tot_tar=totalYearlytardy;
                }
            }

            /*
             Processing the School name and the level information for previous years
             Reports
             Steve Fernandes
             7 August 2017
             */
            if(config.selector=='#header1-'
                || config.selector=='#header2-'
                || config.selector=='#header3-'
                || config.selector=='#header4-'
                || config.selector=='#header5-'
                || config.selector=='#header6-'
                || config.selector=='#header7-'
                || config.selector=='#header8-'
                || config.selector=='#header9-'
                || config.selector=='#header10-'
                || config.selector=='#header11-'
                )
            {
                if(cpt.reportConfig.runPrevYear=='Y')
                {
                    val.schoolname = val.previousSchoolName;
                    val.schooladdress = val.previousSchoolAddr;
                    val.schoolphone = val.previousSchoolPhn;
                    val.schoolcity = val.previousSchoolCity;
                    val.schoolstate = val.previousSchoolState;
                    val.schoolzip = val.previousSchoolZip;
                    val.grade_level=val.previousSchoolYear;
                }

                val.rptLogo = '';
                val.isLogoAvailable = 'No';

                if(typeof val.school_logo != 'undefined' && val.school_logo != '')
                {
                    val.rptLogo = val.school_logo;
                    val.isLogoAvailable = 'Yes';
                }
                else if(typeof val.district_logo != 'undefined' && val.district_logo != '')
                {
                    val.rptLogo = val.district_logo;
                    val.isLogoAvailable = 'Yes';
                }

                var selectedLanguageheader2=val.lang;
                
                var gradeHeader=arrTranslation['gradeDesc'];
                var kg=arrTranslation['kgDesc'];
                var phone=arrTranslation['phoneDesc'];
                var dateHeader=arrTranslation['dateDesc'];
                var repTitle=arrTranslation['reportTitle'];
                var schoolyear=arrTranslation['yearDesc'];
                var studentNameHeader=arrTranslation['studentNameDesc'];
                var HomeRoomHeader=arrTranslation['studentHomeroomDesc'];
                var idNumberHeader=arrTranslation['studentNumberDesc'];
                var courseContinueHeader=arrTranslation['courseContinuedDesc'];
               
                val.gradeHeader=gradeHeader;
                val.kg=kg;
                val.phone=phone;
                val.dateHeader=dateHeader;
                val.repTitle=repTitle;
                val.schoolyear=schoolyear;   
                val.studentNameHeader=studentNameHeader;   
                val.idNumberHeader=idNumberHeader;
                val.HomeRoomHeader=HomeRoomHeader;
                val.courseContinueHeader=courseContinueHeader;
            }

            if(config.selector=='#language-')
            {
                var selectedLanguage=val.lang;

                /*
                 Since we have switched to meeting attendance we have encountered another issue
                 where in if a course has more then one period associated with it then it gets displayed
                 that number of times on the report card
                */

                var arrtempCourseDetails=val.courseDetails;
                var arrUniqueCourseDetails=Array();
                var arrAllreadyAddedToList=Array();
                for(var i=0;i<val.courseDetails.length;i++)
                {
                    if(typeof val.courseDetails[i].course_number!='undefined')
                    {
                        if(arrAllreadyAddedToList.indexOf(val.courseDetails[i].course_number)>-1)
                        {
                            //console.log('Course Already added to the list so ignore'+val.courseDetails[i].course_number);
                        }
                        else
                        {
                            arrAllreadyAddedToList.push(val.courseDetails[i].course_number);
                            arrUniqueCourseDetails.push(val.courseDetails[i]);
                        }
                    }
                }

                //Final formar
                /*
                 Commented This
                 for(var i=0;i<val.courseDetails.length;i++)
                 {
                 if(typeof val.courseDetails[i].course_number!='undefined')
                 {
                 var courseNumber=val.courseDetails[i].course_number;
                 var courseName=val.courseDetails[i].course_name;
                 */

                var arrSubStandaradData=new Array();
                for(var i=0;i<arrUniqueCourseDetails.length;i++)
                {
                    if(typeof arrUniqueCourseDetails[i].course_number!='undefined')
                    {
                        var courseNumber=arrUniqueCourseDetails[i].course_number;
                        if(selectedLanguage==2)
                        {
                            if(typeof arrUniqueCourseDetails[i].COURSE_NAME_TRANSLATED!='undefined' && arrUniqueCourseDetails[i].COURSE_NAME_TRANSLATED!='')
                                var courseName=arrUniqueCourseDetails[i].COURSE_NAME_TRANSLATED;
                            else
                                var courseName=arrUniqueCourseDetails[i].course_name;
                        }
                        else
                        {
                            var courseName=arrUniqueCourseDetails[i].course_name;
                        }
                      
                        var arrTempSubjectStandard=new Array();
                        for(var j=0;j<val.arrAllCourseStandardData.length;j++)
                        {
                            if(typeof val.arrAllCourseStandardData[j].standesc!='undefined')
                            {
                                if(val.arrAllCourseStandardData[j].courseNumber==courseNumber)
                                {
                                    var tempObject={};
                                    tempObject.id=val.arrAllCourseStandardData[j].id;

                                    if(selectedLanguage==2)
                                    {
                                        //Get Spanish translation if it exists
                                        var tempstandardId=val.arrAllCourseStandardData[j].standardId;
                                        var translatedValue=val.arrAllCourseStandardData[j].standesc;

                                        if(arrtranslatedValues.length>0)
                                        {
                                            //Mapping present
                                            for(var t=0;t<arrtranslatedValues.length;t++)
                                            {
                                                if(arrtranslatedValues[t].code==tempstandardId)
                                                {
                                                    if(arrtranslatedValues[t].spanishVal!='' && typeof arrtranslatedValues[t].spanishVal!='undefined')
                                                        translatedValue=arrtranslatedValues[t].spanishVal;
                                                }
                                                    
                                            }
                                        }

                                        tempObject.standesc=translatedValue;

                                        //Spanish or regional Language
                                        /*if(typeof val.arrAllCourseStandardData[j].translatedName!='undefined' && val.arrAllCourseStandardData[j].translatedName!='')
                                            tempObject.standesc=val.arrAllCourseStandardData[j].translatedName;
                                        else
                                            tempObject.standesc=val.arrAllCourseStandardData[j].standesc;
                                        */
                                    }
                                    else
                                    {
                                        //English language
                                        tempObject.standesc=val.arrAllCourseStandardData[j].standesc;
                                    }
                                    
                                    tempObject.sgt1=val.arrAllCourseStandardData[j].sgt1;
                                    tempObject.sgt2=val.arrAllCourseStandardData[j].sgt2;
                                    tempObject.sgt3=val.arrAllCourseStandardData[j].sgt3;
                                    tempObject.sgt4=val.arrAllCourseStandardData[j].sgt4;
                                    tempObject.SortOrder=val.arrAllCourseStandardData[j].SortOrder;
                                    tempObject.courseNumber=val.arrAllCourseStandardData[j].courseNumber;
                                    tempObject.parentStandardId=val.arrAllCourseStandardData[j].parentStandardId;
                                    tempObject.standardId=val.arrAllCourseStandardData[j].standardId;

                                    arrTempSubjectStandard.push(tempObject);
                                }
                            }
                        }

                        var finalTempObject={};
                        finalTempObject.courseName=courseName;
                        finalTempObject.standards=arrTempSubjectStandard;
                        arrSubStandaradData.push(finalTempObject);
                    }
                }

                var arrFinalSubStandardData=new Array();

                /*Process The data to math the UI layout Steve Fernandes */
                for(var v=0;v<arrSubStandaradData.length;v++)
                {
                    var standardsArray=arrSubStandaradData[v].standards;
                    var arrParents=new Array();
                    var arrIndividualStandardIds=new Array();
                    for(var w=0;w<standardsArray.length;w++ )
                    {
                        arrParents.push(standardsArray[w].parentStandardId);
                        arrIndividualStandardIds.push(standardsArray[w].standardId);
                    }

                    var arrUniqueList=new Array();
                    arrUniqueList=arrIndividualStandardIds;

                    //find the interset
                    /*for(var w1=0;w1<arrParents.length;w1++ )
                    {
                        var parentStandard=arrParents[w1];
                        var allready=parseInt(arrUniqueList.indexOf(parentStandard));
                        if(allready>=0)
                        {
                            //do nothing
                        }
                        else
                        {
                            //Check for match
                            for(var w2=0;w2<arrIndividualStandardIds.length;w2++ )
                            {
                                var indvId=arrIndividualStandardIds[w2];
                                if(indvId==parentStandard)
                                    arrUniqueList.push(indvId);
                            }
                        }

                    }*/

                    //identify parents who do not have parents in this array
                    var arrParentsOfParents=Array();
                    if(arrUniqueList.length>0)
                    {
                        for(var iu=0;iu<arrUniqueList.length;iu++ )
                        {
                            var arParent=arrUniqueList[iu];

                            for(var w=0;w<standardsArray.length;w++ )
                            {
                                if(standardsArray[w].standardId==arParent)
                                {
                                    var tempObject={};
                                    tempObject.standardId=arParent;
                                    tempObject.parentid=standardsArray[w].parentStandardId;
                                    arrParentsOfParents.push(tempObject);

                                   // arrParentsOfParents[arParent]=standardsArray[w].parentStandardId;
                                }
                                
                            }
                        }
                    }

                    var arrTopMostLevelData=Array();
                    for(var j=0;j<arrParentsOfParents.length;j++)
                    {
                        var parentId=arrParentsOfParents[j].parentid;
                        if(arrUniqueList.indexOf(parentId)<0)
                        {
                            arrTopMostLevelData.push(arrParentsOfParents[j].standardId);
                        }
                    }

                    if(arrUniqueList.length<=0)
                    {
                        //No need to Reformat data
                        arrFinalSubStandardData.push(arrSubStandaradData[v]);
                    }
                    else
                    {
                        //Format the data
                        //if the

                        /* Using these ids u need to write logic to re-arrange the data
                         *  Logic
                         *  Loop throgh the uniquelist object
                         *  Form Array with all parent
                         * */

                        var tempObjectAfterFormatting={};
                        tempObjectAfterFormatting.courseName=arrSubStandaradData[v].courseName;

                        var arrRearranagedArray=new Array();

                        var topLevelParent=0;
                        topLevelParent=arrUniqueList[0];
                        var arrIntermediatestandards=new Array();

                        for(var w3=0;w3<arrUniqueList.length;w3++ )
                        {
                            var parent=arrUniqueList[w3];
                            var arrTempDataStd= new Array();

                            //Identifying Tope level element identify the elem
                            for(var w4=0;w4<standardsArray.length;w4++ )
                            {
                                if(standardsArray[w4].standardId==parent)
                                {
                                    //Parent found break;
                                    arrRearranagedArray.push(standardsArray[w4]);
                                    arrTempDataStd.push(standardsArray[w4]);
                                }
                            }

                            //Moving children data under section
                            //Identifying Tope level element identify the elem
                            for(var w5=0;w5<standardsArray.length;w5++ )
                            {
                                if(standardsArray[w5].parentStandardId==parent)
                                {
                                    //Parent found break;
                                    arrRearranagedArray.push(standardsArray[w5]);
                                    arrTempDataStd.push(standardsArray[w5]);
                                }
                            }
                            var TempObject={};
                            TempObject.arrData=arrTempDataStd;
                            TempObject.id=parent;

                            arrIntermediatestandards.push(TempObject);
                        }

                        var arrFinalRearrangedData=Array();

                        /*
                         You need to get the children of the top level parent
                         and itterate thogh it till u find the last node
                        */

                        var arrTopParentDetails=Array();
                        for(var countstd=0; countstd<arrIntermediatestandards.length;countstd++)
                        {
                            var parid=arrIntermediatestandards[countstd].id;
                            if(arrTopMostLevelData.indexOf(parid)>=0)
                            {
                                arrTopParentDetails.push(arrIntermediatestandards[countstd])
                            }
                        }

                        //loop through and for an array
                        var arrTempparentstandradData=new Array();
                        for(var countstd=0; countstd<arrIntermediatestandards.length;countstd++)
                        {

                            arrTempparentstandradData[arrIntermediatestandards[countstd].id]=arrIntermediatestandards[countstd].arrData;
                        }

                        //Call this in loof for all parents

                        var arrAllFinalMultipleLeveldata=Array();

                        if(arrTopParentDetails.length>0)
                        {
                            for(var m=0;m<arrTopParentDetails.length;m++)
                            {
                                var arrParentData=arrTopParentDetails[m].arrData;
                                var arrFinalData=cpt.handlebars.processStandardsForDisplay(arrParentData, arrTempparentstandradData,arrFinalRearrangedData);
                            }
                        }
                        else
                        {
                            var arrParentData=arrIntermediatestandards[0].arrData;
                            var arrFinalData=cpt.handlebars.processStandardsForDisplay(arrParentData, arrTempparentstandradData,arrFinalRearrangedData);

                        }

                        tempObjectAfterFormatting.standards=arrFinalData;
                        arrFinalSubStandardData.push(tempObjectAfterFormatting);
                    }
                }

                //Split the data in 2 selection

                var totalCourses=arrFinalSubStandardData.length;
                var halfLength=Number(totalCourses/2);
                var halfLength=halfLength+1;

                var arrLeftSectionDetails=new Array();
                var arrRightSectionDetails=new Array();

                for(var w6=0;w6<arrFinalSubStandardData.length;w6++)
                {
                    if(w6+1<halfLength)
                        arrLeftSectionDetails.push(arrFinalSubStandardData[w6]);
                    else
                        arrRightSectionDetails.push(arrFinalSubStandardData[w6]);
                }

                val.leftSectionData=arrLeftSectionDetails;
                val.rightSectionData=arrRightSectionDetails;
                val.standardData=arrFinalSubStandardData;

                /*
                 Trying to use column nizer plugin si rewrting the code

                */

                val.allStandardsWithRatings=arrFinalSubStandardData;

                //Need to introduce logic to fit the things on pages gracefully

                // started by steve...

                /*
                 V2.5
                 var CONSTANT_FIRST_PAGE_ROWS=33;
                 var CONSTANT_OTHER_PAGE_ROWS=43;
                */

                //V2.6
                var CONSTANT_FIRST_PAGE_ROWS=12;
                var CONSTANT_FIRST_PAGE_RIGHT_ROWS=12;
                var CONSTANT_OTHER_PAGE_ROWS=13;

                /*
                 Updates for Huntley Community schools
                 HCS
                 V2.6HCS
                */

                var ArrLeftSectionFisrtPage=Array();
                var ArrRightSectinFirstPage=Array();
                var ArrFirstPageLeftSection=Array();
                var ArrFirstPageRightSection=Array();
                var ArrThirdPageLeftSection=Array();
                var ArrThirdPageRightSection=Array();

                var ArrFourthPageRightSection=Array();
                var ArrFourthPageLeftSection=Array();
                var ArrFifthPageLeftSection=Array();
                var ArrFifthPageRightSection=Array();
                var ArrSixthPageLeftSection=Array();
                var ArrSixthPageRightSection=Array();
                var ArrSeventhPageLeftSection=Array();
                var ArrSeventhPageRightSection=Array();
                var ArrEightPageLeftSection=Array();
                var ArrEightPageRightSection=Array();

                //This code may never be required but incase we need it
                var stadAndBM="Standards Benchmarks";

                var FisrtPageRightsectionFilled=false;
                var FirstPageleftsectionFilled=false;
                var SecondPageLeftSectionFilled=false;
                var SecondPageRightSectionFilled=false;
                var ThirdPageLeftSectionFilled=false;
                var ThirdPageRightSectionFilled=false;
                var FourthPageLeftSectionFilled=false;
                var FourthPageRightSectionFilled=false;
                var FifthPageLeftSectionFilled=false;
                var FifthPageRightSectionFilled=false;
                var SixthPageLeftSectionFilled=false;
                var SixthPageRightSectionFilled=false;
                var SeventhPageLeftSectionFilled=false;
                var SeventhPageRightSectionFilled=false;
                var EightPageLeftSectionFilled=false;
                var EightPageRightSectionFilled=false;

                var fisrtSectioncounter=1;
                var secondSectioncounter=1;
                var arrFirstSectionLeftsubjects=Array();
                var arrFirstSectionRightsubjects=Array();

                var page1LeftSectionCounter=1;
                var page1rightSectionCounter=1;
                var page2leftSectionCounter=1;
                var page2RightSectionCounter=1;
                var page4leftSectionCounter=1;
                var page4RightSectionCounter=1;
                var page5leftSectionCounter=1;
                var page5RightSectionCounter=1;
                var page6leftSectionCounter=1;
                var page6RightSectionCounter=1;
                var page7leftSectionCounter=1;
                var page7RightSectionCounter=1;
                var page8leftSectionCounter=1;
                var page8RightSectionCounter=1;

                var arrSecondPageLeftSubjects=Array();
                var arrSecondPageRightSubjects=Array();
                var arrThirdPageLeftSubjects=Array();
                var arrThirdPageRightSubjects=Array();
                var arrFourthPageLeftSubjects=Array();
                var arrFourthPageRightSubjects=Array();
                var arrFifthPageLeftSubjects=Array();
                var arrFifthPageRightSubjects=Array();
                var arrSixthPageLeftSubjects=Array();
                var arrSixthPageRightSubjects=Array();
                var arrSeventhPageRightSubjects=Array();
                var arrSeventhPageLeftSubjects=Array();
                var arrEightPageRightSubjects=Array();
                var arrEightPageLeftSubjects=Array();

                //Processing Fisrt section
                var finalStandardLength=arrFinalSubStandardData.length-1;
                val.showquarters=false;
                val.showtrimesters=false;
                val.showsemesters=false;

                if(cpt.reportConfig.useTerm=='q')
                    val.showquarters=true;
                if(cpt.reportConfig.useTerm=='t')
                    val.showtrimesters=true;
                if(cpt.reportConfig.useTerm=='s')
                    val.showsemesters=true;

                    
                var courseContinueHeader=arrTranslation['courseContinuedDesc'];
                val.courseContinueHeader=courseContinueHeader;

                val.userid=key.slice(8, key.length);


                //Enable All section
                //first 2 pages would be shown by default remainig would be displayed if needed
                var theTemplateScript = jQuery("#print-template-section1").html();
                // Compile the template
                var theTemplate = Handlebars.compile(theTemplateScript);
                // Pass our data to the template
                var theCompiledHtml = theTemplate(val);
                jQuery('#firstPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtml);
                jQuery('#firstPage-'+ key.slice(8, key.length)).show();
                var theTemplateScriptFisrtPage = jQuery("#print-template-section2").html();

                // Compile the template
                var theTemplatePage1 = Handlebars.compile(theTemplateScriptFisrtPage);
                // Pass our data to the template
                var theCompiledHtmlPage1 = theTemplatePage1(val);
                jQuery('#secondPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage1);
                jQuery('#secondPage-'+ key.slice(8, key.length)).show();
                var theTemplateScriptSecondPage = jQuery("#print-template-section3").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#thirdPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#thirdPage-'+ key.slice(8, key.length)).show();

                var theTemplateScriptSecondPage = jQuery("#print-template-section4").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#fourthPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#fourthPage-'+ key.slice(8, key.length)).show();

                var theTemplateScriptSecondPage = jQuery("#print-template-section5").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#fifthPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#fifthPage-'+ key.slice(8, key.length)).show();

                var theTemplateScriptSecondPage = jQuery("#print-template-section6").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#sixthPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#sixthPage-'+ key.slice(8, key.length)).show();

                var theTemplateScriptSecondPage = jQuery("#print-template-section7").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#seventhPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#seventhPage-'+ key.slice(8, key.length)).show();

                var theTemplateScriptSecondPage = jQuery("#print-template-section8").html();
                // Compile the template
                var theTemplatePage2 = Handlebars.compile(theTemplateScriptSecondPage);
                // Pass our data to the template
                var theCompiledHtmlPage2 = theTemplatePage2(val);

                jQuery('#eightPageGrades-'+ key.slice(8, key.length)).html(theCompiledHtmlPage2);
                jQuery('#eightPage-'+ key.slice(8, key.length)).show();

                // later hide sections as per the requirements
                //After this keep on appending to pages as well as removing pages..
                //Diplay data in fisrt sectrion

                var content_height = 620;
                var other_content_height=760;// the height of the content, discluding the header/footer

                //pass page ids the rest all
                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){
                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                        columns: 2,
                        target: "#firstPageCL-"+key.slice(8, key.length),
                        overflow: {
                            height: content_height,
                            id: "#standardContent-"+key.slice(8, key.length),
                            doneFunc: function(){
                                //done with page1
                                //buildStandardList(key,content_height)
                                //Remove the header from fisrt page
                                jQuery('#firstPage-'+key.slice(8, key.length)+' >div .first >.Heading:first').remove();

                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                        columns: 2,
                                        target: "#secondPageCL-"+key.slice(8, key.length),
                                        height: other_content_height,
                                        overflow: {
                                            height: other_content_height,
                                            id: "#standardContent-"+key.slice(8, key.length),
                                            buildOnce: true,
                                            doneFunc: function(){
                                                //done with page2 Processing page 3
                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                        columns: 2,
                                                        target: "#thirdPageCL-"+key.slice(8, key.length),
                                                        height: other_content_height,
                                                        overflow: {
                                                            height: other_content_height,
                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                            buildOnce: true,
                                                            doneFunc: function(){
                                                                //done with page3 Processing page 4
                                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                                        columns: 2,
                                                                        target: "#fourthPageCL-"+key.slice(8, key.length),
                                                                        height: other_content_height,
                                                                        overflow: {
                                                                            height: other_content_height,
                                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                                            buildOnce: true,
                                                                            doneFunc: function(){
                                                                                //done with page4 Processing page 5
                                                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                                                        columns: 2,
                                                                                        target: "#fifthPageCL-"+key.slice(8, key.length),
                                                                                        height: other_content_height,
                                                                                        overflow: {
                                                                                            height: other_content_height,
                                                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                                                            buildOnce: true,
                                                                                            doneFunc: function(){
                                                                                                //done with page5 Processing page 6
                                                                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                                                                        columns: 2,
                                                                                                        target: "#sixthPageCL-"+key.slice(8, key.length),
                                                                                                        height: other_content_height,
                                                                                                        overflow: {
                                                                                                            height: other_content_height,
                                                                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                                                                            buildOnce: true,
                                                                                                            doneFunc: function(){
                                                                                                                //done with page6 Processing page 7
                                                                                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                                                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                                                                                        columns: 2,
                                                                                                                        target: "#seventhPageCL-"+key.slice(8, key.length),
                                                                                                                        height: other_content_height,
                                                                                                                        overflow: {
                                                                                                                            height: other_content_height,
                                                                                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                                                                                            buildOnce: true,
                                                                                                                            doneFunc: function(){
                                                                                                                                //done with page7 Processing page 8
                                                                                                                                if(jQuery('#standardContent-'+key.slice(8, key.length)).contents().length > 0){

                                                                                                                                    jQuery('#standardContent-'+key.slice(8, key.length)).columnize({
                                                                                                                                        columns: 2,
                                                                                                                                        target: "#eightPageCL-"+key.slice(8, key.length),
                                                                                                                                        height: other_content_height,
                                                                                                                                        overflow: {
                                                                                                                                            height: other_content_height,
                                                                                                                                            id: "#standardContent-"+key.slice(8, key.length),
                                                                                                                                            buildOnce: true,
                                                                                                                                            doneFunc: function(){
                                                                                                                                                //done with page8 Processing ENDED
                                                                                                                                                var firstRowUndef = false;
                                                                                                                                                var lastRowUndef = false;

                                                                                                                                                if(typeof jQuery('#eightPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                                                                                                {
                                                                                                                                                    lastRowUndef = true;
                                                                                                                                                    jQuery('#eightPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                                                                                                }

                                                                                                                                                if(typeof jQuery('#eightPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                                                                                                {
                                                                                                                                                    firstRowUndef = true;
                                                                                                                                                    jQuery('#eightPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                                                                                                    jQuery('#eightPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                                                                                                                                }

                                                                                                                                                if(firstRowUndef && lastRowUndef)
                                                                                                                                                {
                                                                                                                                                    jQuery('#eightPageBreak-'+key.slice(8, key.length)).remove();
                                                                                                                                                    jQuery('#eightPage-'+ key.slice(8, key.length)).remove();
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    });
                                                                                                                                }
                                                                                                                                else
                                                                                                                                {
                                                                                                                                    removeUnusedPages(8,key);
                                                                                                                                    var firstRowUndef = false;
                                                                                                                                    var lastRowUndef = false;

                                                                                                                                    if(typeof jQuery('#seventhPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                                                                                    {
                                                                                                                                        jQuery('#seventhPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                                                                                        lastRowUndef = true;
                                                                                                                                    }

                                                                                                                                    if(typeof jQuery('#seventhPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                                                                                    {
                                                                                                                                        jQuery('#seventhPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                                                                                        jQuery('#seventhPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                                                                                                                        firstRowUndef = true;
                                                                                                                                    }

                                                                                                                                    if(firstRowUndef && lastRowUndef)
                                                                                                                                    {
                                                                                                                                        jQuery('#seventhPageBreak-'+key.slice(8, key.length)).remove();
                                                                                                                                        jQuery('#seventhPage-'+ key.slice(8, key.length)).remove();
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    });
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    removeUnusedPages(7,key);
                                                                                                                    var firstRowUndef = false;
                                                                                                                    var lastRowUndef = false;

                                                                                                                    if(typeof jQuery('#sixthPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                                                                    {
                                                                                                                        jQuery('#sixthPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                                                                        lastRowUndef = true;
                                                                                                                    }

                                                                                                                    if(typeof jQuery('#sixthPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                                                                    {
                                                                                                                        jQuery('#sixthPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                                                                        jQuery('#sixthPage-'+key.slice(8, key.length)+' >div .first').remove('');

                                                                                                                        firstRowUndef = true;
                                                                                                                    }

                                                                                                                    if(firstRowUndef && lastRowUndef)
                                                                                                                    {
                                                                                                                        jQuery('#sixthPageBreak-'+key.slice(8, key.length)).remove();
                                                                                                                        jQuery('#sixthPage-'+ key.slice(8, key.length)).remove();
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    removeUnusedPages(6,key);
                                                                                                    var firstRowUndef = false;
                                                                                                    var lastRowUndef = false;

                                                                                                    if(typeof jQuery('#fifthPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                                                    {
                                                                                                        jQuery('#fifthPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                                                        lastRowUndef = true;
                                                                                                    }

                                                                                                    if(typeof jQuery('#fifthPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                                                    {
                                                                                                        jQuery('#fifthPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                                                        jQuery('#fifthPage-'+key.slice(8, key.length)+' >div .first').remove('');

                                                                                                        firstRowUndef = true;
                                                                                                    }

                                                                                                    if(firstRowUndef && lastRowUndef)
                                                                                                    {
                                                                                                        jQuery('#fifthPageBreak-'+key.slice(8, key.length)).remove();
                                                                                                        jQuery('#fifthPage-'+ key.slice(8, key.length)).remove();
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    });
                                                                                }
                                                                                else
                                                                                {
                                                                                    removeUnusedPages(5,key);
                                                                                    var firstRowUndef = false;
                                                                                    var lastRowUndef = false;

                                                                                    if(typeof jQuery('#fourthPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                                    {
                                                                                        jQuery('#fourthPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                                        lastRowUndef = true;
                                                                                    }

                                                                                    if(typeof jQuery('#fourthPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                                    {
                                                                                        jQuery('#fourthPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                                        jQuery('#fourthPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                                                                        firstRowUndef = true;
                                                                                    }

                                                                                    if(firstRowUndef && lastRowUndef)
                                                                                    {
                                                                                        jQuery('#fourthPageBreak-'+key.slice(8, key.length)).remove();
                                                                                        jQuery('#fourthPage-'+ key.slice(8, key.length)).remove();
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                                else
                                                                {
                                                                    removeUnusedPages(4,key);
                                                                    var firstRowUndef = false;
                                                                    var lastRowUndef = false;

                                                                    if(typeof jQuery('#thirdPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                                    {
                                                                        jQuery('#thirdPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                                        lastRowUndef = true;
                                                                    }

                                                                    if(typeof jQuery('#thirdPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                                    {
                                                                        jQuery('#thirdPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                                        jQuery('#thirdPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                                                        firstRowUndef = true;
                                                                    }

                                                                    if(firstRowUndef && lastRowUndef)
                                                                    {
                                                                        jQuery('#thirdPageBreak-'+key.slice(8, key.length)).remove();
                                                                        jQuery('#thirdPage-'+ key.slice(8, key.length)).remove();
                                                                    }
                                                                }
                                                            }
                                                        }

                                                    });
                                                }
                                                else
                                                {
                                                    removeUnusedPages(3,key);
                                                    var firstRowUndef = false;
                                                    var lastRowUndef = false;

                                                    if(typeof jQuery('#secondPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                                    {
                                                        jQuery('#secondPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                                        lastRowUndef = true;
                                                    }

                                                    if(typeof jQuery('#secondPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                                    {
                                                        jQuery('#secondPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                                        jQuery('#secondPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                                        firstRowUndef = true;
                                                    }

                                                    if(firstRowUndef && lastRowUndef)
                                                    {
                                                        jQuery('#secondPageBreak-'+key.slice(8, key.length)).remove();
                                                        jQuery('#secondPage-'+ key.slice(8, key.length)).remove();
                                                    }
                                                }
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    //Hide all divs from 2-8
                                    removeUnusedPages(2,key);
                                    var firstRowUndef = false;
                                    var lastRowUndef = false;

                                    if(typeof jQuery('#firstPage-'+key.slice(8, key.length)+' >div .last >.Row').html() == 'undefined')
                                    {
                                        jQuery('#firstPage-'+key.slice(8, key.length)+ '>div .last').remove('');
                                        lastRowUndef = true;
                                    }

                                    if(typeof jQuery('#firstPage-'+key.slice(8, key.length)+' >div .first >.Row').html() == 'undefined')
                                    {
                                        jQuery('#firstPage-'+key.slice(8, key.length)+' >div .last').remove('');
                                        jQuery('#firstPage-'+key.slice(8, key.length)+' >div .first').remove('');
                                        firstRowUndef = true;
                                    }

                                    if(firstRowUndef && lastRowUndef)
                                    {
                                        jQuery('#firstPage-'+ key.slice(8, key.length)).remove();
                                    }
                                }
                            }
                        }
                    });
                }
             }
            else
            {
                if(config.selector=='#comments-')
                {
                    //Process comment using columnizer
                    val.userid=key.slice(8, key.length);

                    //If commenst are empty then apply the class to the boxes so that they have some minimum height.

                    val.cmt1height='';
                    val.cmt2height='';
                    val.cmt3height='';
                    val.cmt4height='';

                    //If comment one is empty then give it height
                    if(val.ct1=='' || val.ct1==' ' || typeof val.ct1=='undefined' )
                    {
                        val.cmt1height="comment_ht";
                    }
                    if(val.ct2=='' || val.ct2==' ' | typeof val.ct2=='undefined' )
                    {
                        val.cmt2height="comment_ht";
                    }
                    if(val.ct3=='' || val.ct3==' ' | typeof val.ct3=='undefined' )
                    {
                        val.cmt3height="comment_ht";
                    }
                    if(val.ct4=='' || val.ct4==' ' | typeof val.ct4=='undefined' )
                    {
                        val.cmt4height="comment_ht";
                    }

                    //show 9 page data
                    //show 10 page 10 data...
                    var theCommentPage1 = jQuery("#print-template-comment0").html();
                    // Compile the template
                    var theCommentPage = Handlebars.compile(theCommentPage1);
                    // Pass our data to the template
                    var theCompiledcommentpage1 = theCommentPage(val);
                    jQuery('#comments1-'+ key.slice(8, key.length)).html(theCompiledcommentpage1);
                    jQuery('#ninePage-'+ key.slice(8, key.length)).show();

                    var theCommentPage2 = jQuery("#print-template-comment1").html();
                    // Compile the template
                    var theCommentPage2 = Handlebars.compile(theCommentPage2);
                    // Pass our data to the template
                    var theCompiledcommentpage2 = theCommentPage2(val);
                    jQuery('#comments2-'+ key.slice(8, key.length)).html(theCompiledcommentpage2);
                    jQuery('#tenPage-'+ key.slice(8, key.length)).show();

                    var theCommentPage3 = jQuery("#print-template-comment2").html();
                    // Compile the template
                    var theCommentPage3 = Handlebars.compile(theCommentPage3);
                    // Pass our data to the template
                    var theCompiledcommentpage3 = theCommentPage3(val);
                    jQuery('#comments3-'+ key.slice(8, key.length)).html(theCompiledcommentpage3);
                    jQuery('#tenPage-'+ key.slice(8, key.length)).show();

                    //Columnize these rows...
                    var content_height_other=800;

                    if(jQuery('#cmt-table-'+key.slice(8, key.length)).contents().length > 0){
                        jQuery('#cmt-table-'+key.slice(8, key.length)).columnize({
                            columns: 1,
                            target: "#firstComment-"+key.slice(8, key.length),
                            overflow: {
                                height: content_height_other,
                                id: "#cmt-table-"+key.slice(8, key.length),
                                buildOnce: true,
                                doneFunc: function(){
                                    //done with page 1 moving to page 2
                                    jQuery(window).resize();
                                    if(jQuery('#cmt-table-'+key.slice(8, key.length)).contents().length > 0){
                                        // here is the columnizer magic
                                        //console.log('Inside Columnizer');
                                        jQuery('#cmt-table-'+key.slice(8, key.length)).columnize({
                                            columns: 1,
                                            target: "#secComment-"+key.slice(8, key.length),
                                            overflow: {
                                                height: content_height_other,
                                                id: "#cmt-table-"+key.slice(8, key.length),
                                                buildOnce: true,
                                                doneFunc: function(){
                                                    //done with processing 2nd page comments
                                                    jQuery(window).resize();
                                                    if(jQuery('#cmt-table-'+key.slice(8, key.length)).contents().length > 0){
                                                        // here is the columnizer magic
                                                        //console.log('Inside Columnizer');
                                                        jQuery(window).resize();
                                                        jQuery('#cmt-table-'+key.slice(8, key.length)).columnize({
                                                            columns: 1,
                                                            target: "#thirdComment-"+key.slice(8, key.length),
                                                            overflow: {
                                                                height: content_height_other,
                                                                id: "#cmt-table-"+key.slice(8, key.length),
                                                                buildOnce: true,
                                                                doneFunc: function(){
                                                                    jQuery(window).resize();
                                                                }
                                                            }
                                                        });
                                                    }
                                                    else
                                                    {
                                                        //Close and remove all remaining pages
                                                        jQuery('#tenPageBreak-'+ key.slice(8, key.length)).remove();
                                                        jQuery('#elevenPage-'+ key.slice(8, key.length)).remove();
                                                        jQuery(window).resize();
                                                    }
                                                }
                                            }
                                        });
                                    }
                                    else
                                    {
                                        //Close and remove all remaining pages

                                        jQuery('#ninePageBreak-'+ key.slice(8, key.length)).remove();
                                        jQuery('#tenPage-'+ key.slice(8, key.length)).remove();
                                        jQuery('#tenPageBreak-'+ key.slice(8, key.length)).remove();
                                        jQuery('#elevenPage-'+ key.slice(8, key.length)).remove();
                                        jQuery(window).resize();
                                    }
                                }
                            }
                        });
                    }
                    else
                    {
                        //Close and remove all remaining pages
                        jQuery(window).resize();
                    }

                    jQuery(window).resize();
                }
                else
                {
                    var html = config.template(val);
                    jQuery(config.selector + key.slice(8, key.length)).html(html);
                }
            }

            jQuery(window).resize();

        });
    },

    processStandardsForDisplay: function (arrChildrenObject, arrIntermediatestandards,arrFinalRearrangedData,arrIntermediatestandards1) {
        if(arrChildrenObject.length>0)
        {
            //put the fisrt record in
            for(var topNode=0;topNode<arrChildrenObject.length;topNode++)
            {
                if(topNode==0)
                {
                    //move this in new temp array
                    arrFinalRearrangedData.push(arrChildrenObject[topNode]);
                }
                else
                {
                    //check if this node has children
                    //If there is an arrau with length >0
                    var parentId=arrChildrenObject[topNode].standardId;

                    var arrSubchildren= arrIntermediatestandards[parentId];
                    /*
                    Loop thorogh this list and get the array
                    //Sometimes it may not even exit if its the last node
                    */

                    if(typeof arrSubchildren !='undefined')
                    {
                        if(arrSubchildren.length>1)
                        {
                            cpt.handlebars.processStandardsForDisplay(arrSubchildren, arrIntermediatestandards,arrFinalRearrangedData);
                        }
                        else
                        {
                            arrFinalRearrangedData.push(arrChildrenObject[topNode]);
                        }
                    }
                    else
                    {
                        //Else You have already reached the last node
                        arrFinalRearrangedData.push(arrChildrenObject[topNode]);
                    }
                }
            }
        }

        return arrFinalRearrangedData;
    },

    /**
     * Grab the template file and render it for merging with the data
     * @param {json} config The configuration from the processTemplates JSON configuration
     * @param {string} config.selector The element in which you will be placing the template
     * @param {string} config.template The template loaded with the data
     * @param {json} value The template and selector for this JSON string to be merged.
     * @param {string} value.templateUrl The returned URL For the template file
     * @param {string} value.selector The element returned for placing the rendered template
     */
    getTemplatesAndRender: function (config, value) {
        jQuery.get(value.templateUrl, function (data) {
            config.selector = value.selector;
            config.template = Handlebars.compile(data);
            cpt.handlebars.jsonToTemplate(config);
        });
    },

    /**
     * If the template in the config is a string, process the data once. If it is an array, process it once per listed
     * template.
     * @param {json} config The configuration from the processTemplates JSON configuration.
     * @param {object} config.templates The templates used in the Handlebars template
     */
    processTemplateOrArray: function (config) {
        if (Object.prototype.toString.call(config.templates) === '[object Array]') {
            jQuery.each(config.templates, function (index, value) {
                cpt.handlebars.getTemplatesAndRender(config, value);
            });
        } else if (Object.prototype.toString.call(config.templates) === '[object Object]') {
            cpt.handlebars.getTemplatesAndRender(config, config.templates);
        }
    },




    /**
     * Retrieve the JSON file, pass the reportConfig as post values, and send to process
     * @param {json} config The configuration from the processTemplates JSON configuration.
     * @param {string} config.JSONUrl The URL of the JSON file
     * @param {object} config.JSONData The Data returned from the JSON file
     */
    getJSONData: function (config) {
        jQuery.getJSON(config.JSONUrl, cpt.reportConfig, function (response) {
            config.JSONData = response;
            cpt.handlebars.processTemplateOrArray(config);
        });
    },

    /**
     * Retrieve template information and begin to process.
     * @param {json} section The section of the grouping which is processed.
     */
    processTemplates: function (section) {
        jQuery.each(section, function (index, value) {
            cpt.handlebars.getJSONData(value);
        });
    },

    /**
     * The setup elements which are passed to all pages.
     */
    setup: function () {
        cpt.handlebars.createSpinner();

        /**
         *  For all templates. Forces the numeric value to a fixed decimal place (ie. {{toFixed weighted 4}})
         */
        Handlebars.registerHelper('toFixed', function (object, points) {
            return parseFloat(object).toFixed(points);
        });

        /**
         * For all templates, compares 2 values in order to determine whether to print an option
         * (ie. {{compare gradelevel "2"}} or {{compare gradelevel ">=" "2"}})
         */
        Handlebars.registerHelper('compare', function (lvalue, operator, rvalue, options) {
            //noinspection JSUnusedLocalSymbols
            var operators, result;
            if (arguments.length < 3) {
                throw new Error('Handlebars Helper \'compare\' needs 2 parameters');
            }
            if (options === undefined) {
                //noinspection JSUnusedAssignment
                options = rvalue;
                //noinspection JSUnusedAssignment
                rvalue = operator;
                //noinspection JSUnusedAssignment
                operator = '===';
            }
            //noinspection JSUnusedAssignment
            operators = {
                '==': function (l, r) {
                    return l === r;
                },
                '===': function (l, r) {
                    return l === r;
                },
                '!=': function (l, r) {
                    return l !== r;
                },
                '!==': function (l, r) {
                    return l !== r;
                },
                '<': function (l, r) {
                    return l < r;
                },
                '>': function (l, r) {
                    return l > r;
                },
                '<=': function (l, r) {
                    return l <= r;
                },
                '>=': function (l, r) {
                    return l >= r;
                },
                'typeof': function (l, r) {
                    return typeof l === r;
                }
            };
        });
    },
    /**
     * Merge a json file from a variable into a handlebars external template and load into an element.
     * @param {string} hbs The URL of the handlebars template
     * @param {string} json The URL of the json string
     * @param {string} element The element you are inserting the rendered template into
     */
    loadTemplate: function (hbs, json, element) {
        jQuery.get(hbs, function (source) {
            var template = Handlebars.compile(source);
            jQuery.getJSON(json, function (context) {
                var html;
                if (Object.prototype.toString.call(context) === '[object Array]') {
                    context.pop();
                }
                html = template(context);
                jQuery(element).html(html);
            });
        });
    }
};
