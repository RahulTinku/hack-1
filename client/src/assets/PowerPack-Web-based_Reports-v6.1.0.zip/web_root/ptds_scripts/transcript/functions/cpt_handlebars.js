
'use strict';

//noinspection JSUnusedGlobalSymbols
/**
 * cpt.handlebars
 * @namespace The namespace for the Handlebars processing
 */
cpt.handlebars = {
  /**
   * Creates the spinner div and begins the spinner when ajax calls begin.
   */
  createSpinner: function () {
    /**
     * Adds the spinner div
     */
    if (document.querySelectorAll('#spinner').length === 0) {
      var spinnerDiv = document.createElement('div');
      spinnerDiv.id = 'spinner';
      document.getElementsByTagName('body')[0].appendChild(spinnerDiv);
    }

    /**
     * Configuration for the javascript spinner
     */
    var Spinner = window.Spinner,
      SpinnerOpts = {
        opts: {
          lines: 13, // The number of lines to draw
          length: 7, // The length of each line
          width: 4, // The line thickness
          radius: 10, // The radius of the inner circle
          corners: 1, // Corner roundness (0..1)
          rotate: 0, // The rotation offset
          color: '#000000', // #rgb or #rrggbb
          speed: 1, // Rounds per second
          trail: 60, // Afterglow percentage
          shadow: false, // Whether to render a shadow
          hwaccel: false, // Whether to use hardware acceleration
          className: 'spinner', // The CSS class to assign to the spinner
          zIndex: 2e9, // The z-index (defaults to 2000000000)
          top: 'auto', // Top position relative to parent in px
          left: 'auto' // Left position relative to parent in px
        },
        target: document.getElementById('spinner')
      };

    /**
     * Starts the spinner
     */
    var spinner = new Spinner(SpinnerOpts.opts).spin(SpinnerOpts.target);

    /**
     * Waits for an ajax calls, shows the spinner, hides the report, and sets the body background to grey.
     */
    jQuery(document).ajaxStart(function () {
      if (!spinner) {
        spinner.start();
      }
      jQuery('#spinner').show();
      jQuery('article').css('display', 'none');
      jQuery('body').attr('bgcolor', '#dddddd').css('opacity', '0.5');
    });

    /**
     * Waits for the completion of all ajax calls, hides the spinner, displays the report, and removes the grey
     * background color.
     */
    jQuery(document).ajaxStop(function () {
      jQuery('#spinner').hide();
      jQuery('article').css('display', 'block');
      jQuery('body').attr('bgcolor', '#ffffff').css('opacity', '1');
    });
  },

  /**
   * Applies the data to the template
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {object} config.JSONData The returned results for the JSONData
   * @param {string} config.template The template used in Handlebars
   * @param {string} config.selector The element where the templated will be placed.
   */
  jsonToTemplate: function (config) {
    jQuery.each(config.JSONData, function (key, val) {

        /*
        Customizing the data as per the Requirement of the re-usable Plugin.
        Steve Fernandes
        12/6/2017
        */

        var allSelectedTerms=val.selectGradeTerm;

        //If blank then use S1,S2 as the default terms
        if(allSelectedTerms.length<=0)
        {
            allSelectedTerms='S1,S2';
        }

        var arrStoredTerms=Array();

        var arrSplitData=allSelectedTerms.split(',');

        for(var m=0; m<arrSplitData.length;m++)
        {
            var tempData=arrSplitData[m];
            tempData=tempData.replace(/'/g, "");
            tempData=tempData.replace(/"/g, "");
            arrStoredTerms.push(tempData);
        }

        var arrAllSchoolGradeData=Array();

        if(val.uniqueSchoolgradeList.length>0)
        {
            for(var i=0;i<val.uniqueSchoolgradeList.length;i++)
            {
                if(typeof val.uniqueSchoolgradeList[i].schoolname!='undefined')
                {
                    var arrTempGradeValues=Array();
                    var arrUniqueCourses=Array();
                    var tempSchoolName=val.uniqueSchoolgradeList[i].schoolname;
                    var tempGradevalue=val.uniqueSchoolgradeList[i].gradeLevel;
                    var tempYearName=val.uniqueSchoolgradeList[i].yearname;
                    var objSchooldata={};
                    objSchooldata.schoolName=tempSchoolName;
                    objSchooldata.gradeLevel=tempGradevalue;
                    objSchooldata.yearName=tempYearName;

                    for(var j=0;j<val.allgrades.length;j++)
                    {
                        if(typeof val.allgrades[j].schoolName!='undefined')
                        {
                            //Check if the 3 parameters match
                            if(
                                val.allgrades[j].schoolName==tempSchoolName
                                &&  val.allgrades[j].gradeLevel==tempGradevalue
                                &&  val.allgrades[j].year==tempYearName
                                )
                            {
                                arrTempGradeValues.push(val.allgrades[j]);
                                var tempObj={};
                                tempObj.courseNumber=val.allgrades[j].courseNumber;
                                tempObj.courseName=val.allgrades[j].course_name;

                                arrUniqueCourses.push(tempObj);
                            }
                        }
                    }

                    var arrUniqueCoursesTemp = jQuery.unique(arrUniqueCourses);
                    var arrTempUniqueList=Array();
                    var arralreadyPreset=Array();

                    for(var t=0;t<arrUniqueCoursesTemp.length;t++)
                    {
                        var tempCourseNumber=arrUniqueCoursesTemp[t].courseNumber+arrUniqueCoursesTemp[t].courseName;
                        var isFound=arralreadyPreset.indexOf(tempCourseNumber);
                        if(isFound>-1)
                        {
                            //element already present ignore
                        }
                        else
                        {
                            //Add element to the list
                            arralreadyPreset.push(tempCourseNumber);
                            arrTempUniqueList.push(arrUniqueCoursesTemp[t]);
                        }
                    }

                    objSchooldata.allSchoolgrades=arrTempGradeValues;
                    objSchooldata.uniqueCourses=arrTempUniqueList;
                    arrAllSchoolGradeData.push(objSchooldata);
                }
            }
        }

        val.arrStoredTerms=arrStoredTerms;

        //accumulate the grades propely
        var totalCreditsearned=0;
        var arrAllCoursesToBeDisplayeddata=Array();
        if(arrAllSchoolGradeData.length>0)
        {
            //Aggregate grades per course and the reporting term
            for(var o=0;o<arrAllSchoolGradeData.length;o++)
            {

                var schoolName=arrAllSchoolGradeData[o].schoolName;
                var gradeLevel=arrAllSchoolGradeData[o].gradeLevel;
                var yearName=arrAllSchoolGradeData[o].yearName;

                var arrUniqueCourses=arrAllSchoolGradeData[o].uniqueCourses;
                var arrAllSchoolgradesData=arrAllSchoolGradeData[o].allSchoolgrades;
                /*
                Loop through each of the course and each year and put them togather
                */

                var arrAllCoursesData=Array();

                for(var uniCL=0;uniCL<arrUniqueCourses.length;uniCL++ )
                {
                    var courseNumber=arrUniqueCourses[uniCL].courseNumber.trim();
                    var courseNameNew=arrUniqueCourses[uniCL].courseName.trim();
                    var arrUniqueGrades=Array();
                    var totalCourseearnedCredits=0;
                    var courseName='';

                    for(var l=0;l<arrStoredTerms.length;l++)
                    {
                        //Gardes need to be rest after the term grade for a particular term has been calculated
                        var grades='';
                        for(var m=0;m<arrAllSchoolgradesData.length;m++)
                        {
                            if(arrAllSchoolgradesData[m].courseNumber.trim()==courseNumber && courseNameNew==arrAllSchoolgradesData[m].course_name.trim() && arrAllSchoolgradesData[m].storecode==arrStoredTerms[l])
                            {
                                courseName=arrAllSchoolgradesData[m].course_name;
                                totalCreditsearned=Number(totalCreditsearned)+Number(arrAllSchoolgradesData[m].earnedCredits);

                                if(val.showPercetGrade==1)
                                {
                                    //show percentage value on transcript instead of grades
                                    if(grades=='')
                                        grades=arrAllSchoolgradesData[m].percent;
                                    else
                                        grades=grades+'<br/>'+arrAllSchoolgradesData[m].percent;
                                }
                                else
                                {
                                    //Show grade value
                                    if(grades=='')
                                        grades=arrAllSchoolgradesData[m].grade;
                                    else
                                        grades=grades+'<br/>'+arrAllSchoolgradesData[m].grade;
                                }

                                totalCourseearnedCredits=Number(totalCourseearnedCredits)+Number(arrAllSchoolgradesData[m].earnedCredits);
                            }
                        }

                        if(grades=='')
                            grades='&nbsp;';

                        arrUniqueGrades[arrStoredTerms[l]]=grades;
                    }

                    //All grades processed for this particular grade
                    //Hence Move it in grade array
                    var tempCourseObject={};
                    tempCourseObject.courseName=courseName;
                    tempCourseObject.earnedCredits=totalCourseearnedCredits;
                    tempCourseObject.earnedgrades=arrUniqueGrades;

                    arrAllCoursesData.push(tempCourseObject);
                }

                /*
                Push the aggregated course data
                back in the main array();

                 */
                var temAllCoursesObject={};
                temAllCoursesObject.schoolName=schoolName;
                temAllCoursesObject.gradeLevel=gradeLevel;
                temAllCoursesObject.yearName=yearName;
                temAllCoursesObject.allCourses=arrAllCoursesData;

                arrAllCoursesToBeDisplayeddata.push(temAllCoursesObject);
            }
        }

        //arrange them in 9-10-11-12

        arrAllCoursesToBeDisplayeddata.sort(function(a,b) {
            return Number(b.gradeLevel) - Number(a.gradeLevel);
        });

        // process the current request courses...

        var curschoolName='';
        var curgradelevel='';
        var curyear='';
        var arrCurrentdata=val.currentCourseEnrollments;
        var arrAllCoursesTemp=Array();

        if(arrCurrentdata.length>0)
        {
            for(var x=0;x<arrCurrentdata.length;x++)
            {
                if(typeof arrCurrentdata[x].courseNumber!='undefined')
                {
                    var tempCourseDetailsObject={};
                    tempCourseDetailsObject.courseName=arrCurrentdata[x].course_name;
                    tempCourseDetailsObject.earnedCredits='&nbsp;';

                    curschoolName=arrCurrentdata[x].schoolName;
                    curyear=arrCurrentdata[x].year;
                    curgradelevel=arrCurrentdata[x].gradeLevel;

                    var arrgradeData=Array();

                    for(var l=0;l<arrStoredTerms.length;l++)
                    {
                        arrgradeData[arrStoredTerms[l]]='&nbsp;';
                    }

                    tempCourseDetailsObject.earnedgrades=arrgradeData;
                    arrAllCoursesTemp.push(tempCourseDetailsObject);
                }
            }

            var schoolInfoObject={};
            schoolInfoObject.allCourses=arrAllCoursesTemp;
            schoolInfoObject.gradeLevel=curgradelevel;
            schoolInfoObject.schoolName=curschoolName;
            schoolInfoObject.yearName=curyear+'- Current Year ';
            //if current year data is to be shown then insert this value
            //For now since the setting is un-avail always show the value

            var arrTempCurrentdata=Array();
            arrTempCurrentdata.push(schoolInfoObject);
            for(var c=0;c<arrAllCoursesToBeDisplayeddata.length;c++)
            {
                arrTempCurrentdata.push(arrAllCoursesToBeDisplayeddata[c]);
            }

            if(val.showCurentYear==1)
                arrAllCoursesToBeDisplayeddata=arrTempCurrentdata;
        }

        val.arrAllCoursesToBeDisplayeddata=arrAllCoursesToBeDisplayeddata;

        //calculating the credits earned so far
        var totalCreditEarned=0;
        if(arrAllCoursesToBeDisplayeddata.length>0)
        {
            for(var r=0;r<arrAllCoursesToBeDisplayeddata.length;r++)
            {
                var arrAllCourseInfo=arrAllCoursesToBeDisplayeddata[r].allCourses;
                if(arrAllCourseInfo.length>0)
                {
                    for(var j=0;j<arrAllCourseInfo.length;j++)
                    {
                        if(arrAllCourseInfo[j].earnedCredits!='&nbsp;' && arrAllCourseInfo[j].earnedCredits!='')
                        {
                            totalCreditEarned=Number(totalCreditEarned)+Number(arrAllCourseInfo[j].earnedCredits);
                            //console.log(totalCreditEarned+'test'+arrAllCourseInfo[j].earnedCredits);
                        }
                    }
                }
            }
        }

        val.totalCreditEarned=totalCreditEarned;

        val.rptLogo = '';
        val.isLogoAvailable = 'No';

        if(typeof val.school_logo != 'undefined' && val.school_logo != '')
        {
            val.rptLogo = val.school_logo;
            val.isLogoAvailable = 'Yes';
        }
        else if(typeof val.district_logo != 'undefined' && val.district_logo != '')
        {
            val.rptLogo = val.district_logo;
            val.isLogoAvailable = 'Yes';
        }

        //Different approach from traditional PS approach
        //Of using Ajax

        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!

        var yyyy = today.getFullYear();

        if(dd<10){
            dd='0'+dd
        }

        if(mm<10){
            mm='0'+mm
        }

        var today = mm+'/'+dd+'/'+yyyy;
        val.printedDate=today;
        val.userid=key.split('-')[1];
        val.graddate='';

        if(val.gradutionCode!='' && val.exitCode==val.gradutionCode)
        {
            val.graddate=val.exitDate;
        }

        /*
        Append the multiple pages which would be removed by the columnizer
        Steve Fernandes
        Process data based on the School Transacript setting.
        */

        /*Display Fisrt page data*/
        var theTemplateScript = jQuery("#print-template-section2").html();
        // Compile the template
        var theTemplate = Handlebars.compile(theTemplateScript);
        // Pass our data to the template
        var theCompiledHtml = theTemplate(val);
        jQuery('#studentTranscriptData-'+ key.slice(8, key.length)).html(theCompiledHtml);

        /*Display Second page data*/
        var theTemplateScript = jQuery("#print-template-section3").html();
        // Compile the template
        var theTemplate = Handlebars.compile(theTemplateScript);
        // Pass our data to the template
        var theCompiledHtml = theTemplate(val);
        jQuery('#secondPage-'+ key.slice(8, key.length)).html(theCompiledHtml);
        jQuery('#secondPage-'+ key.slice(8, key.length)).show();

        /*Display third page data*/
        var theTemplateScript = jQuery("#print-template-section4").html();
        // Compile the template
        var theTemplate = Handlebars.compile(theTemplateScript);
        // Pass our data to the template
        var theCompiledHtml = theTemplate(val);
        jQuery('#thirdPage-'+ key.slice(8, key.length)).html(theCompiledHtml);
        jQuery('#thirdPage-'+ key.slice(8, key.length)).show();

        /*Display fourth page data*/
        var theTemplateScript = jQuery("#print-template-section5").html();
        // Compile the template
        var theTemplate = Handlebars.compile(theTemplateScript);
        // Pass our data to the template
        var theCompiledHtml = theTemplate(val);
        jQuery('#fourthPage-'+ key.slice(8, key.length)).html(theCompiledHtml);
        jQuery('#fourthPage-'+ key.slice(8, key.length)).show();

        //columnizing the data
        var content_height=650;

        //can put loading symeboll but need assurance that this will fin ..

        if(jQuery('#transcriptData-'+key.slice(8, key.length)).contents().length > 0){
            // here is the columnizer magic
            jQuery('#transcriptData-'+key.slice(8, key.length)).columnize({
                columns: 1,
                target: "#FirstPageComment-"+key.slice(8, key.length),
                overflow: {
                    height: content_height,
                    id: "#transcriptData-"+key.slice(8, key.length),
                    doneFunc: function(){
                        //console.log("done with page 1 moving to page 2");
                        jQuery(window).resize();

                        if(jQuery('#transcriptData-'+key.slice(8, key.length)).contents().length > 0){
                            // here is the columnizer magic
                            jQuery('#transcriptData-'+key.slice(8, key.length)).columnize({
                                columns: 1,
                                target: "#secondPageComment-"+key.slice(8, key.length),
                                overflow: {
                                    height: content_height,
                                    id: "#transcriptData-"+key.slice(8, key.length),
                                    doneFunc: function(){
                                        jQuery(window).resize();
                                        if(jQuery('#transcriptData-'+key.slice(8, key.length)).contents().length > 0){
                                            // here is the columnizer magic
                                            jQuery('#transcriptData-'+key.slice(8, key.length)).columnize({
                                                columns: 1,
                                                target: "#thirdPageComment-"+key.slice(8, key.length),
                                                overflow: {
                                                    height: content_height,
                                                    id: "#transcriptData-"+key.slice(8, key.length),
                                                    doneFunc: function(){
                                                        if(jQuery('#transcriptData-'+key.slice(8, key.length)).contents().length > 0){
                                                            // here is the columnizer magic
                                                            jQuery('#transcriptData-'+key.slice(8, key.length)).columnize({
                                                                columns: 1,
                                                                target: "#fourthPageComment-"+key.slice(8, key.length),
                                                                overflow: {
                                                                    height: content_height,
                                                                    id: "#transcriptData-"+key.slice(8, key.length),
                                                                    doneFunc: function(){

                                                                    }
                                                                }
                                                            });
                                                        }
                                                        else
                                                        {
                                                            //Close and remove all remaining pages
                                                            removeUnusedPages(4,key);
                                                        }
                                                    }
                                                }
                                            });
                                        }
                                        else
                                        {
                                            //Close and remove all remaining pages
                                            removeUnusedPages(3,key);
                                        }
                                    }
                                }
                            });
                        }
                        else
                        {
                            //Close and remove all remaining pages
                            removeUnusedPages(2,key);
                        }
                    }
                }
            });
        }
        else
        {
            //Close and remove all page
        }

        jQuery(window).resize();
    });
  },

  /**
   * Grab the template file and render it for merging with the data
   * @param {json} config The configuration from the processTemplates JSON configuration
   * @param {string} config.selector The element in which you will be placing the template
   * @param {string} config.template The template loaded with the data
   * @param {json} value The template and selector for this JSON string to be merged.
   * @param {string} value.templateUrl The returned URL For the template file
   * @param {string} value.selector The element returned for placing the rendered template
   */
  getTemplatesAndRender: function (config, value) {
    jQuery.get(value.templateUrl, function (data) {
      config.selector = value.selector;
      config.template = Handlebars.compile(data);
      cpt.handlebars.jsonToTemplate(config);
    });
  },

  /**
   * If the template in the config is a string, process the data once. If it is an array, process it once per listed
   * template.
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {object} config.templates The templates used in the Handlebars template
   */
  processTemplateOrArray: function (config) {
    if (Object.prototype.toString.call(config.templates) === '[object Array]') {
      jQuery.each(config.templates, function (index, value) {
        cpt.handlebars.getTemplatesAndRender(config, value);
      });
    } else if (Object.prototype.toString.call(config.templates) === '[object Object]') {
      cpt.handlebars.getTemplatesAndRender(config, config.templates);
    }
  },

  /**
   * Retrieve the JSON file, pass the reportConfig as post values, and send to process
   * @param {json} config The configuration from the processTemplates JSON configuration.
   * @param {string} config.JSONUrl The URL of the JSON file
   * @param {object} config.JSONData The Data returned from the JSON file
   */
  getJSONData: function (config) {
    jQuery.getJSON(config.JSONUrl, cpt.reportConfig, function (response) {
      config.JSONData = response;
   //   cpt.handlebars.processTemplateOrArray(config);
        cpt.handlebars.jsonToTemplate(config);
    });
  },

  /**
   * Retrieve template information and begin to process.
   * @param {json} section The section of the grouping which is processed.
   */
  processTemplates: function (section) {
    jQuery.each(section, function (index, value) {
      cpt.handlebars.getJSONData(value);
    });
  },

  /**
   * The setup elements which are passed to all pages.
   */
  setup: function () {
    cpt.handlebars.createSpinner();

    /**
     *  For all templates. Forces the numeric value to a fixed decimal place (ie. {{toFixed weighted 4}})
     */
    Handlebars.registerHelper('toFixed', function (object, points) {
      return parseFloat(object).toFixed(points);
    });

    /**
     * For all templates, compares 2 values in order to determine whether to print an option
     * (ie. {{compare gradelevel "2"}} or {{compare gradelevel ">=" "2"}})
     */
    Handlebars.registerHelper('compare', function (lvalue, operator, rvalue, options) {
      //noinspection JSUnusedLocalSymbols
      var operators, result;
      if (arguments.length < 3) {
        throw new Error('Handlebars Helper \'compare\' needs 2 parameters');
      }
      if (options === undefined) {
        //noinspection JSUnusedAssignment
        options = rvalue;
        //noinspection JSUnusedAssignment
        rvalue = operator;
        //noinspection JSUnusedAssignment
        operator = '===';
      }
      //noinspection JSUnusedAssignment
      operators = {
        '==': function (l, r) {
          return l === r;
        },
        '===': function (l, r) {
          return l === r;
        },
        '!=': function (l, r) {
          return l !== r;
        },
        '!==': function (l, r) {
          return l !== r;
        },
        '<': function (l, r) {
          return l < r;
        },
        '>': function (l, r) {
          return l > r;
        },
        '<=': function (l, r) {
          return l <= r;
        },
        '>=': function (l, r) {
          return l >= r;
        },
        'typeof': function (l, r) {
          return typeof l === r;
        }
      };
      if (!operators[operator]) {
        throw new Error('Handlebars Helper COMPARE does not know the operator ' + operator);
      }
      result = operators[operator](lvalue, rvalue);
      if (result) {
        return options.fn(this);
      } else {
        return options.inverse(this);
      }
    });
  },
  /**
   * Merge a json file from a variable into a handlebars external template and load into an element.
   * @param {string} hbs The URL of the handlebars template
   * @param {string} json The URL of the json string
   * @param {string} element The element you are inserting the rendered template into
   */
  loadTemplate: function (hbs, json, element) {
    jQuery.get(hbs, function (source) {
      var template = Handlebars.compile(source);
      jQuery.getJSON(json, function (context) {
        var html;
        if (Object.prototype.toString.call(context) === '[object Array]') {
          context.pop();
        }
        html = template(context);
        jQuery(element).html(html);
      });
    });
  }
};
