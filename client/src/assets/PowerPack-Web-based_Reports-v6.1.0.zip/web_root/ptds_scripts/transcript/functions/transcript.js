//Processing data using handle bars
Handlebars.registerHelper('displayGradeData', function(arrCourseData,arrStoreCodeData,showEarnedCredits) {
    var html='';

    for(i=0;i<arrCourseData.length;i++)
    {
        //Create new row for the school and grade
        var schoolName=arrCourseData[i].schoolName;
        var gradeLevel=arrCourseData[i].gradeLevel;
        var yearName=arrCourseData[i].yearName;
        /*
        Using dvs inatead of table
        Because tables cannot be split using columnizer
        Steve Fernandes
        */

        html=html+'<div class="Row dontsplit" style="width:810px;">';
        html=html+'<div class="cellleft" style="width:405px;font-style: italic;background-color: #afafa0;color: #fff;font-size: 13px;text-align:left;padding-left:4px;">';
        html=html+'<b>'+schoolName +'</b> - '+yearName+' - Grade:'+gradeLevel+'</div>';

        //put the grades and show credits if enabled
        //if show credits is enabled then only display them here
        var noOfStoreCodes=arrStoreCodeData.length;

        var minWidth=0;
        if(showEarnedCredits==1)
        {
            var tempcount=noOfStoreCodes+1;
            minWidth=405/tempcount;
        }
        else
        {
            minWidth=405/noOfStoreCodes;
        }

        var lastElement=noOfStoreCodes-1;
        if(showEarnedCredits==1)
        {
             //Show grades along with credits
            for(var m=0;m<arrStoreCodeData.length;m++)
            {
                html=html+'<div class="cellmiddle" style="width:'+minWidth+'px;font-style: italic;background-color: #afafa0;color: #fff;font-size: 13px;text-align:center;padding-left:4px;">'+arrStoreCodeData[m]+'</div>';
            }

            html=html+'<div class="cellright" style="width:'+minWidth+'px;font-style: italic;background-color: #afafa0;color: #fff;font-size: 13px;text-align:center;padding-left:4px;">Earned Credits</div></div>';
        }
        else
        {
            //Show only grades
            for(var m=0;m<arrStoreCodeData.length;m++)
            {
                if(m==lastElement)
                    html=html+' <div class="cellright" style="width:'+minWidth+'px;font-style: italic;background-color: #afafa0;color: #fff;font-size: 13px;text-align:center;padding-left:4px;">'+arrStoreCodeData[m]+'</div></div>';
                else
                    html=html+'<div class="cellmiddle" style="width:'+minWidth+'px;font-style: italic;background-color: #afafa0;color: #fff;font-size: 13px;text-align:center;padding-left:4px;">'+arrStoreCodeData[m]+'</div>';
            }
        }

        //Show the courses
        var arrAllSchoolCourseData=arrCourseData[i].allCourses;
        if(arrAllSchoolCourseData.length>0)
        {
            for(var n=0;n<arrAllSchoolCourseData.length;n++)
            {
                var coursename=arrAllSchoolCourseData[n].courseName;
                var earnedCredits=arrAllSchoolCourseData[n].earnedCredits;
                var arrratingData=arrAllSchoolCourseData[n].earnedgrades;

                html=html+'<div class="Row dontsplit" style="width:810px">';
                html=html+'<div class="cellleft" style="width:405px">'+coursename+'</div>';

                if(showEarnedCredits==1)
                {
                    for(var m1=0;m1<arrStoreCodeData.length;m1++)
                    {
                        var currentStoreCode=arrStoreCodeData[m1];
                        if(typeof arrratingData[currentStoreCode]!='undefined')
                        {
                            html=html+'<div class="cellmiddle" style="width:'+minWidth+'px;text-align: center;">'+arrratingData[currentStoreCode]+'</div>';
                        }
                        else
                        {
                            //value is undefined use NBSP instead
                            html=html+'<div class="cellmiddle" style="width:'+minWidth+'px;text-align: center;"></div>';
                        }
                    }

                    html=html+'<div class="cellright" style="width:'+minWidth+'px">'+earnedCredits+'</div></div>';
                }
                else
                {
                    //do not show earned credits
                    for(var m1=0;m1<arrStoreCodeData.length;m1++)
                    {
                        var currentStoreCode=arrStoreCodeData[m1];

                        if(m1==lastElement)
                        {
                            if(typeof arrratingData[currentStoreCode]!='undefined')
                            {
                                html=html+'<div class="cellright" style="width:'+minWidth+'px;text-align: center;">'+arrratingData[currentStoreCode]+'</div></div>';
                            }
                            else
                            {
                                //value is undefined use NBSP instead
                                html=html+'<div class="cellright" style="width:'+minWidth+'px; text-align: center;"></div></div>';
                            }
                        }
                        else
                        {
                            if(typeof arrratingData[currentStoreCode]!='undefined')
                            {
                                html=html+'<div class="cellmiddle" style="width:'+minWidth+'px; text-align: center;">'+arrratingData[currentStoreCode]+'</div>';
                            }
                            else
                            {
                                //value is undefined use NBSP instead
                                html=html+'<div class="cellmiddle" style="width:'+minWidth+'px; text-align: center;"></div>';
                            }
                        }
                    }
                }
            }
        }
    }
    return html;
});