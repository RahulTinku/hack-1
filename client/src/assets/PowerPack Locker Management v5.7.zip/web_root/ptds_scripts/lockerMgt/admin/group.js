/**
 * Created with JetBrains PhpStorm.
 * User: steve_fernandes
 * Date: 3/20/17
 * Time: 10:54 AM
 * To change this template use File | Settings | File Templates.
 */



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    jQuery(this).find('input').val('');
    jQuery(this).find('#dialog-error').empty();
    jQuery(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};


var showCannotDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termCannotDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showGroupDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/groups/templates/addGroup.html';
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#add-new-dialog-container').html(response);
            jQuery('#group-form').submit(submitgroup);
            jQuery('#dialog-error').hide();
            var $termDialog=$j('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showGroupDataForEdit=function(dcid){
    var url='/admin/lockerMgt/groups/templates/editGroup.html?id='+dcid;
    jQuery.ajax({
        url: url,
        success: function(response){
           // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#edit-dialog-container').html(response);
            jQuery('#group-form-edit').submit(submitgroup);
            jQuery('#dialog-error-edit').hide();
            var $termDialogEdit=$j('#edit-dialog-container');
            showEditDialog($termDialogEdit);
        },
        error: function(){
            //do nothing
        }
    });
}

var deleteGroup=function(id){
    showDeleteDialog();
    jQuery('#idToBeDeleted').val(id);
};



/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    jQuery('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deleteGroup=function(id){
    //Confirm before delete
    var retObject=checkGroupLockerCount(id);
    console.log('returned data'+retObject);

  
};


var checkGroupLockerCount=function(id){
    //Confirm before delete
   
    var url='/admin/lockerMgt/groups/json/getLockerCount.json.html?id='+id;
    jQuery.ajax({
            url: url,
            async:false,
            success: function(response){
               // jQuery('#delete-dialog-container').dialog('close');
               // console.log('Reloading the page');
               // window.location='/admin/lockerMgt/groups/groups.html';
               console.log('The response'+response);
               if(response>0)
               {
                   //data present cannot delete
                   showCannotDeleteDialog();
               }
               else
               {
                   //data absent can delete
                    showDeleteDialog();
                     jQuery('#idToBeDeleted').val(id);
               }

               return response;

            },
            error: deleteError
        });
};


var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
    //Not sure if data is present so dont allow to delete
    showCannotDeleteDialog();
};

var deleteGroupFromDB=function(){
    //Confirm before delete
    var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/groups/json/deletegroup.json.html?id='+id;
    jQuery.ajax({
            url: url,
            success: function(){
                jQuery('#delete-dialog-container').dialog('close');
                console.log('Reloading the page');
                window.location='/admin/lockerMgt/groups/groups.html';
            },
            error: deleteError
        });
};



var submitgroup=  function(e) {
    //validations are already handled using HTML5
     return true;
};



$j(document).ready(function(){
        jQuery('#add-new-dialog-container').hide();
        jQuery('#delete-dialog-container').hide();
        jQuery('#dialog-error').hide();
        jQuery('#dialog-errorDelete').hide();
        jQuery('#edit-dialog-container').hide();
        jQuery('#cannotdelete-dialog-container').hide();
        jQuery('#new-button').click(function() {
            showGroupDataForAdd();
        });

});
/**
 * Ajax call to show the loading dialog box while saving the data
 */
$j(document).ajaxStart(function() {
    loadingDialog();
});
$j(document).ajaxStop(function() {
    closeLoading();
});