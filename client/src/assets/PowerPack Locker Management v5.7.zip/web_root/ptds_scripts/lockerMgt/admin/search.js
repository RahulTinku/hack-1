/**
 * Created with JetBrains PhpStorm.
 * User: Steve
 * Date: 3/22/17
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Ajax call to show the loading dialog box while saving the data
 */
$jq(document).ajaxStart(function() {
    loadingDialog('Loading..');
});
$jq(document).ajaxStop(function() {
    closeLoading();
});



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    $jq(this).find('input').val('');
    $jq(this).find('#dialog-error').empty();
    $jq(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 450
    });
};


var showstudentDialog = function() {
    var $termStudentDialog = cpt.pageConfig.$studentListDialog;
    $termStudentDialog.show();
    $termStudentDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 500
    });
};

showAssociatedStudents=function(lockerNumber) {

    var url='/admin/lockerMgt/lockers/templates/studentUsingLocker.html?lockerNumber='+lockerNumber;
    $jq.ajax({
        url: url,
        success: function(response){
           console.log(response);

            $jq('#studentsDetails').html(response);

            var $termDialog=$jq('#student-dialog-container');
            showstudentDialog($termDialog);
        },
        error: function(){
            //do nothing
            var $termDialog=$jq('#student-dialog-container');
            showstudentDialog($termDialog);
        }
    });




};




var showLockerDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/lockers/templates/addLocker.html?fr=search';
    $jq.ajax({
        url: url,
        success: function(response){
            // $jq('#delete-dialog-container').dialog('close');
            $jq('#add-new-dialog-container').html(response);
            $jq('#lock-form').submit(submitlocker);
            $jq('#dialog-error').hide();
            var $termDialog=$jq('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showLockerDataForEdit=function(dcid){
    var url='/admin/lockerMgt/lockers/templates/editLocker.html?fr=search&id='+dcid;
    $jq.ajax({
        url: url,
        success: function(response){
            // $jq('#delete-dialog-container').dialog('close');
            $jq('#edit-dialog-container').html(response);
            $jq('#group-form-edit').submit(submitlocker);
            $jq('#dialog-error-edit').hide();
            var $termDialogEdit=$jq('#edit-dialog-container');
            showEditDialog($termDialogEdit);
            var lockerGrpDropDown=$jq('#lockerGroup').html();
            $jq('#lockerGroupId').html(lockerGrpDropDown);
            var selectedGroup=$jq('#groupNumber').val();
            $jq('#lockerGroup').remove();
            $jq("#LOCKER_GROUP_ID").val(selectedGroup);

            var lockDetailDropd=$jq('#lockid').html();
            $jq('#lockNumberDetails').html(lockDetailDropd);
            var selectedLockNumber=$jq('#lockNumber').val();
            $jq('#lockid').remove();
            $jq("#LOCKER_COMBO_SERIAL_NUM").val(selectedLockNumber);
        },
        error: function(){
            //do nothing
        }
    });
}





/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    $jq('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deletelocker=function(id){
    //Confirm before delete
    showDeleteDialog();
    $jq('#idToBeDeleted').val(id);
};


var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};

var deleteLockerFromDB=function(){
    //Confirm before delete
    var id=$jq('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+id;
    $jq.ajax({
        url: url,
        success: function(){
            $jq('#delete-dialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/search.html';
        },
        error: deleteError
    });
};



var submitlocker=  function(e) {
    //validations are already handled using HTML5
    return true;
};
$jq(document).ready(function(){

    //Use Handle bars to assign data then attach the datatables events...
    var theTemplateScript = $jq("#print-data-Template").html();

    console.log('The Data'+theTemplateScript);

    // Compile the template
    var theTemplate = Handlebars.compile(theTemplateScript);
    // Pass our data to the template
    var theCompiledHtml = theTemplate(availLockerDataObject);
    // Add the compiled html to the page
    $jq('#LockerDiv').html(theCompiledHtml);

    var pageName= $jq('#pageName').val();

    $jq('#lockerTbl').DataTable({
        paging: true,
        dom:'Blfrtip',
        buttons:[
            {
                extend:'pdf',
                text: 'PDF',
                title: pageName,
                footer:false,
                orientation : 'landscape',
                pageSize : 'A2',
                exportOptions:{
                    columns:[0,1,3,2,25,26,27,28,29,30,31,32,4,7,8,9,10,11,12,13,14]
                }
            },
            {
                extend:'csv',
                footer:false,
                exportOptions:{
                    columns:[15,1,16,6,17,18,19,20,21,22,23,24,4,7,8,9,10,11,12,13,14]
                }
            }
        ],
        columnDefs: [{
            targets:[6,15,16,17,18,19,20,21,22,23,24],
            render: function(data, type, row, meta){
                return "=\"" + data +"\"";
            }
        }]
    });
    //New Functionality For the Add locker stuff
    $jq('#add-new-dialog-container').hide();
    $jq('#delete-dialog-container').hide();
    $jq('#dialog-error').hide();
    $jq('#dialog-errorDelete').hide();
    $jq('#edit-dialog-container').hide();
    $jq('#student-dialog-container').hide();

    $jq('#new-button').click(function() {
        showLockerDataForAdd();
    });
});


toggleSearchFormView=function()
{
    if(!$jq('#searchForm').is(':visible'))
    {
        $jq('#searchForm').show();
        if($jq('#t1').hasClass('collapsed')) $jq('#t1').removeClass('collapsed');$jq('#t1').addClass('expanded');
    }
    else if($jq('#searchForm').is(':visible'))
    {
        $jq('#searchForm').hide();
        if($jq('#t1').hasClass('expanded')) $jq('#t1').removeClass('expanded');$jq('#t1').addClass('collapsed');
    }



};



validateLockerNumber=function()
{
    //Get the Locker number

    var lockerNumber=$jq('#LOCKER_NUMBER').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForAddCase.json.html?lockerNumber='+lockerNumber;
    $jq.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}

validateLockerNumberForEdit=function()
{
    //Get the Locker number

    var lockerNumber=$jq('#LOCKER_NUMBER').val();
    var id=$jq('#id').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForEditCase.json.html?lockerNumber='+lockerNumber+'&id='+id;
    $jq.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}


