/**
 * Created with JetBrains PhpStorm.
 * User: Steve
 * Date: 3/22/17
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Ajax call to show the loading dialog box while saving the data
 */
$jq(document).ajaxStart(function() {
    loadingDialog('Loading..');
});
$jq(document).ajaxStop(function() {
    closeLoading();
});



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    $jq(this).find('input').val('');
    $jq(this).find('#dialog-error').empty();
    $jq(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showCannotDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termCannotDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 450
    });
};

var showLockerDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/lockers/templates/addLocker.html';
    $jq.ajax({
        url: url,
        success: function(response){
            // $jq('#delete-dialog-container').dialog('close');
            $jq('#add-new-dialog-container').html(response);
            $jq('#lock-form').submit(submitlocker);
            $jq('#dialog-error').hide();
            var $termDialog=$jq('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showLockerDataForEdit=function(dcid){
    var url='/admin/lockerMgt/lockers/templates/editLocker.html?id='+dcid;
    $jq.ajax({
        url: url,
        success: function(response){
            // $jq('#delete-dialog-container').dialog('close');
            $jq('#edit-dialog-container').html(response);
            $jq('#group-form-edit').submit(submitlocker);
            $jq('#dialog-error-edit').hide();
            var $termDialogEdit=$jq('#edit-dialog-container');
            showEditDialog($termDialogEdit);

            var lockerGrpDropDown=$jq('#lockerGroup').html();
            $jq('#lockerGroupId').html(lockerGrpDropDown);
            var selectedGroup=$jq('#groupNumber').val();
            $jq('#lockerGroup').remove();
            $jq("#LOCKER_GROUP_ID").val(selectedGroup);

            var lockDetailDropd=$jq('#lockid').html();
            $jq('#lockNumberDetails').html(lockDetailDropd);
            var selectedLockNumber=$jq('#lockNumber').val();
            $jq('#lockid').remove();
            $jq("#LOCKER_COMBO_SERIAL_NUM").val(selectedLockNumber);




        },
        error: function(){
            //do nothing
        }
    });
}





/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    $jq('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deletelocker=function(id){
    //Confirm before delete
    checkLockLockerCount(id)
   // showDeleteDialog();
   // $jq('#idToBeDeleted').val(id);
};


var checkLockLockerCount=function(id){
    //Confirm before delete
   
    var url='/admin/lockerMgt/lockers/json/getLockerStudentCount.json.html?id='+id;
    $jq.ajax({
            url: url,
            async:false,
            success: function(response){
               // jQuery('#delete-dialog-container').dialog('close');
               // console.log('Reloading the page');
               // window.location='/admin/lockerMgt/groups/groups.html';
               console.log('The response'+response);
               if(response>0)
               {
                   //data present cannot delete
                   showCannotDeleteDialog();
               }
               else
               {
                   //data absent can delete
                    showDeleteDialog();
                    $jq('#idToBeDeleted').val(id);
               }

               return response;

            },
            error: deleteError
        });
};

var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
        showCannotDeleteDialog();
};

var deleteLockerFromDB=function(){
    //Confirm before delete
    var id=$jq('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+id;
    $jq.ajax({
        url: url,
        success: function(){
            $jq('#delete-dialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });
};


var deleteAllLockers=function(id){
    //Confirm before delete
    showDeleteAllDialog();
   // $jq('#idToBeDeleted').val(id);
};
var showDeleteAllDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteAllDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};




var deleteAllLockerFromDB=function(){
    //Confirm before delete
   // var id=$jq('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteAllLocker.json.html?schoolid='+cpt.pageConfig.schoolId;
    $jq.ajax({
        url: url,
        success: function(){
            $jq('#delete-Alldialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });
};



var showDeleteSelecetedDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteSelectedDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};



var deleteSelectedLockers=function(id){
    //Confirm before delete

    //Confirm before delete
    var arrSelected=Array();
    $jq("input:checked").each(
        function(key,value){
            arrSelected.push($jq(this).val());
        });
    if(arrSelected.length>0)
    {

        showDeleteSelecetedDialog();
    }
    else
    {
        alert('Please select Lockers which you want to delete.');
    }

    // $jq('#idToBeDeleted').val(id);
};


var selectAll=function(){
   // $jq("input").prop('checked',true);
   $jq("input").each(function(){ console.log($jq(this).attr('disabled')); if($jq(this).attr('disabled')!=='disabled'){$jq(this).prop('checked',true)}});

};


var deleteSelecetedLockerFromDB=function(){

    var arrSelected=Array();
    $jq("input:checked").each(
        function(key,value){
            arrSelected.push($jq(this).val());
        });
    if(arrSelected.length>0)
    {
        sectionsCreated=0;

        var numberOfLockers=arrSelected.length;
        var selectedlockers='';
        for(var i=0;i<arrSelected.length;i++)
        {
           /* if(selectedlockers=='')
                selectedlockers=arrSelected[i];
            else
                selectedlockers=selectedlockers+','+  arrSelected[i];*/


            var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+arrSelected[i];
            $jq.ajax({
                url: url,
                success: function(){
                    /*$jq('#delete-dialog-container').dialog('close');
                    console.log('Reloading the page');
                    window.location='/admin/lockerMgt/lockers/locker.html';*/
                    sectionsCreated++;
                    //  $jq('#section-count').html(sectionsCreated);
                    if(numberOfLockers==sectionsCreated)
                    {
                        $jq('#delete-Selecteddialog-container').dialog('close');
                       // console.log('Reloading the page');
                     //   console.log('Inhere');
                        window.location='/admin/lockerMgt/lockers/locker.html';

                    }
                },
                error: deleteError
            });

        }
    }

    //Confirm before delete
    //var id=$jq('#idToBeDeleted').val();
   /* var url='/admin/lockerMgt/lockers/json/deleteSelectedLocker.json.html?ids='+selectedlockers;
    $jq.ajax({
        url: url,
        success: function(){
    $jq('#delete-Selecteddialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });*/
};



var submitlocker=  function(e) {
    //validations are already handled using HTML5
    return true;
};


/*

 */

$jq(document).ready(function(){
    var table=$jq('#lockerTbl').DataTable({
        paging: true,
        "aLengthMenu": [[10, 25, 50,100,250,500, -1 ], [10, 25, 50,100,250,500, "All" ]],
        dom:'Blfrtip',
        buttons:[
            {
                extend:'pdf',
                footer:false,
                exportOptions:{
                    columns:[1,2,3,4,5]
                }
            },
           {
                extend:'csv',
                footer:false,
                exportOptions:{
                    columns:[8,2,7,9,5]
                }
            }
        ],
        columnDefs: [{
            targets:[7,8,9],
            render: function(data, type, row, meta){
                return "=\"" + data +"\"";
            }
        }

        ]
    });

    console.log('Testing auto reload logic');

    //New Functionality For the Add locker stuff
    $jq('#add-new-dialog-container').hide();
    $jq('#delete-dialog-container').hide();
    $jq('#delete-Alldialog-container').hide();
    $jq('#dialog-errorAllDelete').hide();
    $jq('#delete-Selecteddialog-container').hide();
    $jq('#dialog-errorSelectedDelete').hide();

    $jq('#dialog-error').hide();
    $jq('#dialog-errorDelete').hide();
    $jq('#edit-dialog-container').hide();
    $jq('#cannotdelete-dialog-container').hide();
    $jq('#new-button').click(function() {
        showLockerDataForAdd();
    });
});


validateLockerNumber=function()
{
    //Get the Locker number

    var lockerNumber=$jq('#LOCKER_NUMBER').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForAddCase.json.html?lockerNumber='+lockerNumber;
    $jq.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}

validateLockerNumberForEdit=function()
{
    //Get the Locker number

    var lockerNumber=$jq('#LOCKER_NUMBER').val();
    var id=$jq('#id').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForEditCase.json.html?lockerNumber='+lockerNumber+'&id='+id;
    $jq.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}



toggleSearchFormView=function()
{
    if(!$jq('#searchForm').is(':visible'))
    {
        $jq('#searchForm').show();
        if($jq('#t1').hasClass('collapsed')) $jq('#t1').removeClass('collapsed');$jq('#t1').addClass('expanded');
    }
    else if($jq('#searchForm').is(':visible'))
    {
        $jq('#searchForm').hide();
        if($jq('#t1').hasClass('expanded')) $jq('#t1').removeClass('expanded');$jq('#t1').addClass('collapsed');
    }



};

