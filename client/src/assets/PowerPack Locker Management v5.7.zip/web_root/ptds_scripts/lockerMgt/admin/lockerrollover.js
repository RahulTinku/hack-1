/*
Original Locker.js
 */

/**
 * Created with JetBrains PhpStorm.
 * User: Steve
 * Date: 3/22/17
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Ajax call to show the loading dialog box while saving the data
 */
jQuery(document).ajaxStart(function() {
    loadingDialog('Loading..');
});
jQuery(document).ajaxStop(function() {
    closeLoading();
});



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    jQuery(this).find('input').val('');
    jQuery(this).find('#dialog-error').empty();
    jQuery(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 450
    });
};

var showLockerDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/lockers/templates/addLocker.html';
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#add-new-dialog-container').html(response);
            jQuery('#lock-form').submit(submitlocker);
            jQuery('#dialog-error').hide();
            var $termDialog=jQuery('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showLockerDataForEdit=function(dcid){
    var url='/admin/lockerMgt/lockers/templates/editLocker.html?id='+dcid;
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#edit-dialog-container').html(response);
            jQuery('#group-form-edit').submit(submitlocker);
            jQuery('#dialog-error-edit').hide();
            var $termDialogEdit=jQuery('#edit-dialog-container');
            showEditDialog($termDialogEdit);

            var lockerGrpDropDown=jQuery('#lockerGroup').html();
            jQuery('#lockerGroupId').html(lockerGrpDropDown);
            var selectedGroup=jQuery('#groupNumber').val();
            jQuery('#lockerGroup').remove();
            jQuery("#LOCKER_GROUP_ID").val(selectedGroup);

            var lockDetailDropd=jQuery('#lockid').html();
            jQuery('#lockNumberDetails').html(lockDetailDropd);
            var selectedLockNumber=jQuery('#lockNumber').val();
            jQuery('#lockid').remove();
            jQuery("#LOCKER_COMBO_SERIAL_NUM").val(selectedLockNumber);




        },
        error: function(){
            //do nothing
        }
    });
}





/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    jQuery('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deletelocker=function(id){
    //Confirm before delete
    showDeleteDialog();
    jQuery('#idToBeDeleted').val(id);
};


var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};

var deleteLockerFromDB=function(){
    //Confirm before delete
    var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+id;
    jQuery.ajax({
        url: url,
        success: function(){
            jQuery('#delete-dialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });
};


var deleteAllLockers=function(id){
    //Confirm before delete
    showDeleteAllDialog();
   // jQuery('#idToBeDeleted').val(id);
};
var showDeleteAllDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteAllDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};




var deleteAllLockerFromDB=function(){
    //Confirm before delete
   // var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteAllLocker.json.html?schoolid='+cpt.pageConfig.schoolId;
    jQuery.ajax({
        url: url,
        success: function(){
            jQuery('#delete-Alldialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });
};



var showDeleteSelecetedDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteSelectedDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};



var deleteSelectedLockers=function(id){
    //Confirm before delete

    //Confirm before delete
    var arrSelected=Array();
    jQuery("input:checked").each(
        function(key,value){
            arrSelected.push(jQuery(this).val());
        });
    if(arrSelected.length>0)
    {

        showDeleteSelecetedDialog();
    }
    else
    {
        alert('Please select Lockers which you want to delete.');
    }

    // jQuery('#idToBeDeleted').val(id);
};


var selectAll=function(){
    jQuery("input").prop('checked',true);
};


var deleteSelecetedLockerFromDB=function(){

    var arrSelected=Array();
    jQuery("input:checked").each(
        function(key,value){
            arrSelected.push(jQuery(this).val());
        });
    if(arrSelected.length>0)
    {
        sectionsCreated=0;

        var numberOfLockers=arrSelected.length;
        var selectedlockers='';
        for(var i=0;i<arrSelected.length;i++)
        {
           /* if(selectedlockers=='')
                selectedlockers=arrSelected[i];
            else
                selectedlockers=selectedlockers+','+  arrSelected[i];*/


            var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+arrSelected[i];
            jQuery.ajax({
                url: url,
                success: function(){
                    /*jQuery('#delete-dialog-container').dialog('close');
                    console.log('Reloading the page');
                    window.location='/admin/lockerMgt/lockers/locker.html';*/
                    sectionsCreated++;
                    //  jQuery('#section-count').html(sectionsCreated);
                    if(numberOfLockers==sectionsCreated)
                    {
                        jQuery('#delete-Selecteddialog-container').dialog('close');
                       // console.log('Reloading the page');
                     //   console.log('Inhere');
                        window.location='/admin/lockerMgt/lockers/locker.html';

                    }
                },
                error: deleteError
            });

        }
    }

    //Confirm before delete
    //var id=jQuery('#idToBeDeleted').val();
   /* var url='/admin/lockerMgt/lockers/json/deleteSelectedLocker.json.html?ids='+selectedlockers;
    jQuery.ajax({
        url: url,
        success: function(){
            jQuery('#delete-Selecteddialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/locker.html';
        },
        error: deleteError
    });*/
};



var submitlocker=  function(e) {
    //validations are already handled using HTML5
    return true;
};


/*

 */

jQuery(document).ready(function(){
    var table=jQuery('#lockerTbl').DataTable({
        paging: true,
        "aLengthMenu": [[10, 25, 50,100,250,500, -1 ], [10, 25, 50,100,250,500, "All" ]],
        dom:'Blfrtip',
        buttons:[
            {
                extend:'pdf',
                footer:false,
                exportOptions:{
                    columns:[1,2,3,4,5]
                }
            },
           {
                extend:'csv',
                footer:false,
                exportOptions:{
                    columns:[8,2,7,9,5]
                }
            }
        ],
        columnDefs: [{
            targets:[7,8,9],
            render: function(data, type, row, meta){
                return "=\"" + data +"\"";
            }
        }

        ]
    });

    console.log('Testing auto reload logic');

    //New Functionality For the Add locker stuff
    jQuery('#add-new-dialog-container').hide();
    jQuery('#delete-dialog-container').hide();
    jQuery('#delete-Alldialog-container').hide();
    jQuery('#dialog-errorAllDelete').hide();
    jQuery('#delete-Selecteddialog-container').hide();
    jQuery('#dialog-errorSelectedDelete').hide();

    jQuery('#dialog-error').hide();
    jQuery('#dialog-errorDelete').hide();
    jQuery('#edit-dialog-container').hide();
    jQuery('#new-button').click(function() {
        showLockerDataForAdd();
    });
});


validateLockerNumber=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCKER_NUMBER').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForAddCase.json.html?lockerNumber='+lockerNumber;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(obj.lockerId+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}

validateLockerNumberForEdit=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCKER_NUMBER').val();
    var id=jQuery('#id').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForEditCase.json.html?lockerNumber='+lockerNumber+'&id='+id;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(obj.lockerId+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}



toggleSearchFormView=function()
{
    if(!jQuery('#searchForm').is(':visible'))
    {
        jQuery('#searchForm').show();
        if(jQuery('#t1').hasClass('collapsed')) jQuery('#t1').removeClass('collapsed');jQuery('#t1').addClass('expanded');
    }
    else if(jQuery('#searchForm').is(':visible'))
    {
        jQuery('#searchForm').hide();
        if(jQuery('#t1').hasClass('expanded')) jQuery('#t1').removeClass('expanded');jQuery('#t1').addClass('collapsed');
    }



};

