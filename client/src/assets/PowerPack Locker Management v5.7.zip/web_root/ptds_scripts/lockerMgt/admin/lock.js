/**
 * Created with JetBrains PhpStorm.
 * User: steve_fernandes
 * Date: 3/20/17
 * Time: 10:54 AM
 * To change this template use File | Settings | File Templates.
 */



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    jQuery(this).find('input').val('');
    jQuery(this).find('#dialog-error').empty();
    jQuery(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showCannotDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termCannotDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showLockDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/locks/templates/addLock.html';
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#add-new-dialog-container').html(response);
            jQuery('#lock-form').submit(submitlock);
            jQuery('#dialog-error').hide();
            var $termDialog=$j('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showLockDataForEdit=function(dcid){
    var url='/admin/lockerMgt/locks/templates/editLock.html?id='+dcid;
    jQuery.ajax({
        url: url,
        success: function(response){
           // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#edit-dialog-container').html(response);
            jQuery('#group-form-edit').submit(submitlock);
            jQuery('#dialog-error-edit').hide();
            var $termDialogEdit=$j('#edit-dialog-container');
            showEditDialog($termDialogEdit);
        },
        error: function(){
            //do nothing
        }
    });
}





/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    jQuery('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deletelock=function(id){

    checkLockLockerCount(id);
    //Confirm before delete
    //showDeleteDialog();
    //jQuery('#idToBeDeleted').val(id);
};



var checkLockLockerCount=function(id){
    //Confirm before delete
   
    var url='/admin/lockerMgt/locks/json/getLockerCount.json.html?id='+id;
    jQuery.ajax({
            url: url,
            async:false,
            success: function(response){
               // jQuery('#delete-dialog-container').dialog('close');
               // console.log('Reloading the page');
               // window.location='/admin/lockerMgt/groups/groups.html';
               console.log('The response'+response);
               if(response>0)
               {
                   //data present cannot delete
                   showCannotDeleteDialog();
               }
               else
               {
                   //data absent can delete
                    showDeleteDialog();
                    jQuery('#idToBeDeleted').val(id);
               }

               return response;

            },
            error: deleteError
        });
};





var showDeleteAllDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteAllDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};
var deleteAllPadlock=function(id){
    //Confirm before delete
    showDeleteAllDialog();
  //  jQuery('#idToBeDeleted').val(id);
};

var deleteAllLockFromDB=function(){
    //Confirm before delete
   // var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/locks/json/deleteAlllock.json.html?schoolid='+cpt.pageConfig.schoolId;
    jQuery.ajax({
        url: url,
        success: function(){
            jQuery('#deleteAll-dialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/locks/locks.html';
        },
        error: deleteError
    });
};

deleteSelectedLockFromDB


var showDeleteSelectedDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteSelectedDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};
var deleteSelectedPadlock=function(id){
    //Confirm before delete
    var arrSelected=Array();
    jQuery("input:checked").each(
        function(key,value){
            arrSelected.push(jQuery(this).val());
        });
    if(arrSelected.length>0)
    {

        showDeleteSelectedDialog();
    }
    else
    {
        alert('Please select padlocks which you want to delete.');
    }

    //  jQuery('#idToBeDeleted').val(id);
};



var selectAll=function(){
   // jQuery("input").prop('checked',true);
   jQuery("input").each(function(){ console.log(jQuery(this).attr('disabled')); if(jQuery(this).attr('disabled')!=='disabled'){jQuery(this).prop('checked',true)}});
};



var deleteSelectedLockFromDB=function(){

    var arrSelected=Array();
    jQuery("input:checked").each(
        function(key,value){
            arrSelected.push(jQuery(this).val());
        });
    if(arrSelected.length>0)
    {
        var selectedpadlocks='';
        sectionsCreated=0;

        var numberOfLocks=arrSelected.length;

        for(var i=0;i<arrSelected.length;i++)
        {
            /*if(selectedpadlocks=='')
            selectedpadlocks=arrSelected[i];
            else
             selectedpadlocks=selectedpadlocks+','+  arrSelected[i];*/

            var url='/admin/lockerMgt/locks/json/deletelock.json.html?id='+arrSelected[i];



            jQuery.ajax({
                url: url,
                success: function(){
                  //  jQuery('#deleteSelected-dialog-container').dialog('close');
                   // console.log('Reloading the page');
                   // window.location='/admin/lockerMgt/locks/locks.html';
                    sectionsCreated++;
                  //  jQuery('#section-count').html(sectionsCreated);
                    if(numberOfLocks==sectionsCreated)
                    {
                        jQuery('#deleteSelected-dialog-container').dialog('close');
                        console.log('Inhere');
                        window.location='/admin/lockerMgt/locks/locks.html';

                    }

                },
                error: deleteError
            });



        }
    }



   // var url='/admin/lockerMgt/locks/json/deleteSelectedlock.json.html?ids='+selectedpadlocks;


};








var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
        showCannotDeleteDialog();
};

var deleteLockFromDB=function(){
    //Confirm before delete
    var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/locks/json/deletelock.json.html?id='+id;
    jQuery.ajax({
            url: url,
            success: function(){
                jQuery('#delete-dialog-container').dialog('close');
                console.log('Reloading the page');
                window.location='/admin/lockerMgt/locks/locks.html';
            },
            error: deleteError
        });
};



var submitlock=  function(e) {
    //validations are already handled using HTML5
     return true;
};



$j(document).ready(function(){




        jQuery('#add-new-dialog-container').hide();
        jQuery('#delete-dialog-container').hide();
        jQuery('#deleteAll-dialog-container').hide();
        jQuery('#dialog-errorAllDelete').hide();
        jQuery('#deleteSelected-dialog-container').hide();
        jQuery('#dialog-errorSelectedDelete').hide();
    console.log('Testing auto reload logic');


        jQuery('#dialog-error').hide();
        jQuery('#dialog-errorDelete').hide();
        jQuery('#edit-dialog-container').hide();
        jQuery('#cannotdelete-dialog-container').hide();
        jQuery('#new-button').click(function() {
            showLockDataForAdd();
        });

});
/**
 * Ajax call to show the loading dialog box while saving the data
 */
$j(document).ajaxStart(function() {
    loadingDialog();
});
$j(document).ajaxStop(function() {
    closeLoading();
});


validateLockNumber=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCK_SERIAL_NUMBER').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/locks/json/checkDuplicateLockSerialNumberForAdd.json.html?lockNubcer='+lockerNumber;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Lock belonging to this school. Please choose another Lock number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}

validateLockNumberForEdit=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCK_SERIAL_NUMBER').val();
    var id=jQuery('#id').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/locks/json/checkDuplicateLockSerialNumberForEdit.json.html?lockNubcer='+lockerNumber+'&id='+id;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockId!='')
            {
                console.log('Dumplicate Locker number');
                alert(lockerNumber+' is already used by another Lock belonging to this school. Please choose another Lock number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}