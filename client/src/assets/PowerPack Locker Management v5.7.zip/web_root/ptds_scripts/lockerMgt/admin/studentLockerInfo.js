function searchLocker()
{
    //Get List of all avail lockers for selected group
    var selectedGroup=0;
    selectedGroup=jQuery("#lockerGroup option:selected").val();
    console.log('The selected Locker Group'+selectedGroup);

    //Call Ajax to get the locker list... TBD
    var url='/admin/lockerMgt/lockers/templates/getAvailableLockers.html?id='+selectedGroup;
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            console.log(response);
            jQuery('#availLockerDetails').html(response);


        },
        error: function(){
            //do nothing
        }
    });


}



jQuery('#submitthi').click(function(event) {
    event.preventDefault();
    //Get the locker number
    var lockerNumber=jQuery('#lockerNumber').val();
    var lockerCombination=jQuery('#lockerCombination').val();
    console.log('The Locker Number'+lockerNumber);
    console.log('The Locker combination'+lockerCombination);
    if(lockerCombination=='' && lockerNumber=='')
    {
        //If both the locker number and the combination are blank then someone is trying to clear the
        //Locker details for the student
        // Allow him to submit the form
        jQuery('#lockerdetails').submit();
    }
    else if(lockerNumber=='')
    {
        alert('Please enter a valid Locker Number.');
        return false;
    }
    else
    {

        var studentId=jQuery('#studentDCID').val();

        //Call Ajax to get the locker list... TBD
        var url='/admin/lockerMgt/lockers/json/validateLockerDetails.json.html?lockerNumber='+lockerNumber+'&studentIdentifier='+studentId;
        jQuery.ajax({
            url: url,
            success: function(response){
                // jQuery('#delete-dialog-container').dialog('close');
                console.log('We will decide after logging the response');
                console.log(response);
                var obj = JSON.parse(response);
                console.log(obj);
                if(typeof obj.LockerDetails.currentSeq !='undefined')
                {
                    //jQuery('#lockerCombination').val(obj.LockerDetails.currentSeq);
                    //If someone tries to save and if its not avalible then
                    jQuery('#lockerdetails').submit();
                    //return true;
                }
                else
                {
                    alert('This Locker is not available. Please select another locker.');
                    return false;
                }



                // jQuery('#availLockerDetails').html(response);


            },
            error: function(){
                //do nothing
                return false;
            }
        });
    }
});


function getLockerCombination()
{
    //Get the locker number
    var lockerNumber=jQuery('#lockerNumber').val();
    console.log('The Locker Number');
    if(lockerNumber=='')
    {
        alert('Please enter a valid Locker Number.');
        return false;
    }
    else
    {

        var studentId=jQuery('#studentDCID').val();

        //Call Ajax to get the locker list... TBD
        var url='/admin/lockerMgt/lockers/json/validateLockerDetails.json.html?lockerNumber='+lockerNumber+'&studentIdentifier='+studentId;
        jQuery.ajax({
            url: url,
            success: function(response){
                // jQuery('#delete-dialog-container').dialog('close');
                console.log('We will decide after logging the response');
                console.log(response);
                var obj = JSON.parse(response);
                console.log(obj);
                if(typeof obj.LockerDetails.currentSeq !='undefined')
                {
                    jQuery('#lockerCombination').val(obj.LockerDetails.currentSeq);
                }
                else
                {
                    alert('This Locker is not available. Please select another locker.');
                    return false;
                }



               // jQuery('#availLockerDetails').html(response);


            },
            error: function(){
                //do nothing
            }
        });
    }
}



/*Function to populate the locker details on the page*/
function useSelected(lockerNumber,lockercombination)
{
    jQuery('#lockerNumber').val(lockerNumber);
    jQuery('#lockerCombination').val(lockercombination);
    jQuery('#search-dialog-container').dialog('close');


}


/* Validate before save*/






/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    jQuery(this).find('input').val('');
    jQuery(this).find('#dialog-error').empty();
    jQuery(this).find('#dialog-error').hide();
};

var showSearchDialog = function() {
    var $termSearchDialog = cpt.pageConfig.$termSearchDialog;
    $termSearchDialog.show();
    $termSearchDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 500
    });
};

openSearch=function() {
    showSearchDialog();
};

$j(document).ready(function(){
    jQuery('#search-dialog-container').hide();
    //jQuery('#delete-dialog-container').hide();
    //jQuery('#dialog-error').hide();
    jQuery('#dialog-errorDelete').hide();
    //jQuery('#edit-dialog-container').hide();
   /* jQuery('#new-button').click(function() {
        showLockDataForAdd();
    });*/

});
/**
 * Ajax call to show the loading dialog box while saving the data
 */
$j(document).ajaxStart(function() {
    loadingDialog();
});
$j(document).ajaxStop(function() {
    closeLoading();
});