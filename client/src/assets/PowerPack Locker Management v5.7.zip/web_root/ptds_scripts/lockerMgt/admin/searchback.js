/**
 * Created with JetBrains PhpStorm.
 * User: Steve
 * Date: 3/22/17
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Ajax call to show the loading dialog box while saving the data
 */
jQuery(document).ajaxStart(function() {
    loadingDialog('Loading..');
});
jQuery(document).ajaxStop(function() {
    closeLoading();
});



/**
 * Closes the detail dialog and reloads the terms
 */
var dialogClose = function() {
    jQuery(this).find('input').val('');
    jQuery(this).find('#dialog-error').empty();
    jQuery(this).find('#dialog-error').hide();
};

/**
 * Opens the detail dialog
 * @param {object=} term
 */
var showDialog = function($termDialog) {
    var $termDialog = $termDialog;
    $termDialog.show();
    $termDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showDeleteDialog = function() {
    var $termDeleteDialog = cpt.pageConfig.$termDeleteDialog;
    $termDeleteDialog.show();
    $termDeleteDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 350
    });
};

var showEditDialog = function($termDialogEdit) {
    var $termEditDialog = $termDialogEdit;
    $termEditDialog.show();
    $termEditDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 450
    });
};


var showstudentDialog = function() {
    var $termStudentDialog = cpt.pageConfig.$studentListDialog;
    $termStudentDialog.show();
    $termStudentDialog.dialog({
        modal: true,
        close: dialogClose,
        width: 487,
        height: 500
    });
};

showAssociatedStudents=function(lockerNumber) {

    var url='/admin/lockerMgt/lockers/templates/studentUsingLocker.html?lockerNumber='+lockerNumber;
    jQuery.ajax({
        url: url,
        success: function(response){
           console.log(response);

            jQuery('#studentsDetails').html(response);

            var $termDialog=jQuery('#student-dialog-container');
            showstudentDialog($termDialog);
        },
        error: function(){
            //do nothing
            var $termDialog=jQuery('#student-dialog-container');
            showstudentDialog($termDialog);
        }
    });




};




var showLockerDataForAdd=function(){
    //Get the HTML data
    var url='/admin/lockerMgt/lockers/templates/addLocker.html?fr=search';
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#add-new-dialog-container').html(response);
            jQuery('#lock-form').submit(submitlocker);
            jQuery('#dialog-error').hide();
            var $termDialog=jQuery('#add-new-dialog-container');
            showEditDialog($termDialog);
        },
        error: function(){
            //do nothing
        }
    });
}


var showLockerDataForEdit=function(dcid){
    var url='/admin/lockerMgt/lockers/templates/editLocker.html?fr=search&id='+dcid;
    jQuery.ajax({
        url: url,
        success: function(response){
            // jQuery('#delete-dialog-container').dialog('close');
            jQuery('#edit-dialog-container').html(response);
            jQuery('#group-form-edit').submit(submitlocker);
            jQuery('#dialog-error-edit').hide();
            var $termDialogEdit=jQuery('#edit-dialog-container');
            showEditDialog($termDialogEdit);
            var lockerGrpDropDown=jQuery('#lockerGroup').html();
            jQuery('#lockerGroupId').html(lockerGrpDropDown);
            var selectedGroup=jQuery('#groupNumber').val();
            jQuery('#lockerGroup').remove();
            jQuery("#LOCKER_GROUP_ID").val(selectedGroup);

            var lockDetailDropd=jQuery('#lockid').html();
            jQuery('#lockNumberDetails').html(lockDetailDropd);
            var selectedLockNumber=jQuery('#lockNumber').val();
            jQuery('#lockid').remove();
            jQuery("#LOCKER_COMBO_SERIAL_NUM").val(selectedLockNumber);
        },
        error: function(){
            //do nothing
        }
    });
}





/**
 * Called after a successful POST/PUT call to the API, reloads the terms table
 */
var submitSuccess = function(message) {
    jQuery('#dialog-container').dialog('close');
    //Reload the Display group section
};

/**
 * Called on error w/ POST/PUT to api.
 */
var submitError = function() {
    alert('There was an error saving your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};


var deletelocker=function(id){
    //Confirm before delete
    showDeleteDialog();
    jQuery('#idToBeDeleted').val(id);
};


var deleteError = function() {
    alert('There was an error while deleting your changes. Please try again.\n' +
        'If the issue persists, contact your administrator');
};

var deleteLockerFromDB=function(){
    //Confirm before delete
    var id=jQuery('#idToBeDeleted').val();
    var url='/admin/lockerMgt/lockers/json/deleteLocker.json.html?id='+id;
    jQuery.ajax({
        url: url,
        success: function(){
            jQuery('#delete-dialog-container').dialog('close');
            console.log('Reloading the page');
            window.location='/admin/lockerMgt/lockers/search.html';
        },
        error: deleteError
    });
};



var submitlocker=  function(e) {
    //validations are already handled using HTML5
    return true;
};
jQuery(document).ready(function(){

    //Use Handle bars to assign data then attach the datatables events...
    var theTemplateScript = jQuery("#print-data-Template").html();

    console.log('The Data'+theTemplateScript);

    // Compile the template
    var theTemplate = Handlebars.compile(theTemplateScript);
    // Pass our data to the template
    var theCompiledHtml = theTemplate(availLockerDataObject);
    // Add the compiled html to the page
    jQuery('#LockerDiv').html(theCompiledHtml);

    var pageName= jQuery('#pageName').val();

    jQuery('#lockerTbl').DataTable({
        paging: true,
        dom:'Blfrtip',
        buttons:[
            {
                extend:'pdf',
                text: 'PDF',
                title: pageName,
                footer:false,
                exportOptions:{
                    columns:[0,1,2,3,4,7,8,9,10]
                }
            },
            {
                extend:'csv',
                footer:false,
                exportOptions:{
                    columns:[11,1,6,12,4,7,8,9,10]
                }
            }
        ],
        columnDefs: [{
            targets:[6,11,12],
            render: function(data, type, row, meta){
                return "=\"" + data +"\"";
            }
        }]
    });
    //New Functionality For the Add locker stuff
    jQuery('#add-new-dialog-container').hide();
    jQuery('#delete-dialog-container').hide();
    jQuery('#dialog-error').hide();
    jQuery('#dialog-errorDelete').hide();
    jQuery('#edit-dialog-container').hide();
    jQuery('#student-dialog-container').hide();

    jQuery('#new-button').click(function() {
        showLockerDataForAdd();
    });
});


toggleSearchFormView=function()
{
    if(!jQuery('#searchForm').is(':visible'))
    {
        jQuery('#searchForm').show();
        if(jQuery('#t1').hasClass('collapsed')) jQuery('#t1').removeClass('collapsed');jQuery('#t1').addClass('expanded');
    }
    else if(jQuery('#searchForm').is(':visible'))
    {
        jQuery('#searchForm').hide();
        if(jQuery('#t1').hasClass('expanded')) jQuery('#t1').removeClass('expanded');jQuery('#t1').addClass('collapsed');
    }



};



validateLockerNumber=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCKER_NUMBER').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForAddCase.json.html?lockerNumber='+lockerNumber;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(obj.lockerId+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}

validateLockerNumberForEdit=function()
{
    //Get the Locker number

    var lockerNumber=jQuery('#LOCKER_NUMBER').val();
    var id=jQuery('#id').val();
    var noDuplicate=true;
    var url='/admin/lockerMgt/lockers/json/checkDuplicateLockerForEditCase.json.html?lockerNumber='+lockerNumber+'&id='+id;
    jQuery.ajax({
        url: url,
        async:false,
        success: function(message){
            console.log(message);
            var obj = JSON.parse(message);
            if(obj.lockerId!='')
            {
                console.log('Dumplicate Locker number');
                alert(obj.lockerId+' is already used by another Locker belonging to this school. Please choose another Locker number.');
                noDuplicate= false;
            }
            else
            {
                //Unique Locker Number
                noDuplicate= true;
            }
        },
        error: function(){
            noDuplicate= false;
        }
    });
    return noDuplicate;
}


