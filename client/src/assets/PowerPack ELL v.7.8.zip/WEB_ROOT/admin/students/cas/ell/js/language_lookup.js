// do this once dom loaded and ready
var primaryLanguage = [ { label: "English", value: "00" },
  { label: "Spanish", value: "01" },
  { label: "Vietnamese", value: "02" },
  { label: "Cantonese", value: "03" },
  { label: "Korean", value: "04" },
  { label: "Filipino (Pilipino or Tagalog)", value: "05" },
  { label: "Portuguese", value: "06" },
  { label: "Mandarin (Putonghua)", value: "07" },
  { label: "Japanese", value: "08" },
  { label: "Khmer (Cambodian)", value: "09" },
  { label: "Lao", value: "10" },
  { label: "Arabic", value: "11" },
  { label: "Armenian", value: "12" },
  { label: "Burmese", value: "13" },
  { label: "Dutch", value: "15" },
  { label: "Farsi (Persian)", value: "16" },
  { label: "French", value: "17" },
  { label: "German", value: "18" },
  { label: "Greek", value: "19" },
  { label: "Chamorro (Guamanian)", value: "20" },
  { label: "Hebrew", value: "21" },
  { label: "Hindi", value: "22" },
  { label: "Hmong", value: "23" },
  { label: "Hungarian", value: "24" },
  { label: "Ilocano", value: "25" },
  { label: "Indonesian", value: "26" },
  { label: "Italian", value: "27" },
  { label: "Punjabi", value: "28" },
  { label: "Russian", value: "29" },
  { label: "Samoan", value: "30" },
  { label: "Thai", value: "32" },
  { label: "Turkish", value: "33" },
  { label: "Tongan", value: "34" },
  { label: "Urdu", value: "35" },
  { label: "Cebuano (Visayan)", value: "36" },
  { label: "Sign Language", value: "37" },
  { label: "Ukrainian", value: "38" },
  { label: "Chaozhou (Chiuchow)", value: "39" },
  { label: "Pashto", value: "40" },
  { label: "Polish", value: "41" },
  { label: "Assyrian", value: "42" },
  { label: "Gujarati", value: "43" },
  { label: "Mien (Yao)", value: "44" },
  { label: "Rumanian", value: "45" },
  { label: "Taiwanese", value: "46" },
  { label: "Lahu", value: "47" },
  { label: "Marshallese", value: "48" },
  { label: "Mixteco", value: "49" },
  { label: "Khmu", value: "50" },
  { label: "Kurdish (Kurdi, Kurmanji)", value: "51" },
  { label: "Serbo-Croatian (Bosnian, Croatian, Serbian)", value: "52" },
  { label: "Toishanese", value: "53" },
  { label: "Chaldean", value: "54" },
  { label: "Albanian", value: "56" },
  { label: "Tigrinya", value: "57" },
  { label: "Somali", value: "60" },
  { label: "Bengali", value: "61" },
  { label: "Telugu", value: "62" },
  { label: "Tamil", value: "63" },
  { label: "Marathi", value: "64" },
  { label: "Kannada", value: "65" },
  { label: "Amharic", value: "66" },
  { label: "Bulgarian", value: "67" },
  { label: "Kikuyu", value: "68" },
  { label: "Kashmiri", value: "69" },
  { label: "Swedish", value: "70" },
  { label: "Zapoteco", value: "71" },
  { label: "Uzbek", value: "72" },
  { label: "Karen", value: "73" },
  { label: "Other non-English languages", value: "99" },
  { label: "Unknown", value: "UU" },
  { label: "", value: "" } ];

function primaryLanguageLookup(code)
{
	var codesTable = { "00": ["English"],
			"01": ["Spanish"],
			"02": ["Vietnamese"],
			"03": ["Cantonese"],
			"04": ["Korean"],
			"05": ["Filipino (Pilipino or Tagalog)"],
			"06": ["Portuguese"],
			"07": ["Mandarin (Putonghua)"],
			"08": ["Japanese"],
			"09": ["Khmer (Cambodian)"],
			"10": ["Lao"],
			"11": ["Arabic"],
			"12": ["Armenian"],
			"13": ["Burmese"],
			"15": ["Dutch"],
			"16": ["Farsi (Persian)"],
			"17": ["French"],
			"18": ["German"],
			"19": ["Greek"],
			"20": ["Chamorro (Guamanian)"],
			"21": ["Hebrew"],
			"22": ["Hindi"],
			"23": ["Hmong"],
			"24": ["Hungarian"],
			"25": ["Ilocano"],
			"26": ["Indonesian"],
			"27": ["Italian"],
			"28": ["Punjabi"],
			"29": ["Russian"],
			"30": ["Samoan"],
			"32": ["Thai"],
			"33": ["Turkish"],
			"34": ["Tongan"],
			"35": ["Urdu"],
			"36": ["Cebuano (Visayan)"],
			"37": ["Sign Language"],
			"38": ["Ukrainian"],
			"39": ["Chaozhou (Chiuchow)"],
			"40": ["Pashto"],
			"41": ["Polish"],
			"42": ["Assyrian"],
			"43": ["Gujarati"],
			"44": ["Mien (Yao)"],
			"45": ["Rumanian"],
			"46": ["Taiwanese"],
			"47": ["Lahu"],
			"48": ["Marshallese"],
			"49": ["Mixteco"],
			"50": ["Khmu"],
			"51": ["Kurdish (Kurdi, Kurmanji)"],
			"52": ["Serbo-Croatian (Bosnian, Croatian, Serbian)"],
			"53": ["Toishanese"],
			"54": ["Chaldean"],
			"56": ["Albanian"],
			"57": ["Tigrinya"],
			"60": ["Somali"],
			"61": ["Bengali"],
			"62": ["Telugu"],
			"63": ["Tamil"],
			"64": ["Marathi"],
			"65": ["Kannada"],
			"66": ["Amharic"],
			"67": ["Bulgarian"],
			"68": ["Kikuyu"],
			"69": ["Kashmiri"],
			"70": ["Swedish"],
			"71": ["Zapoteco"],
			"72": ["Uzbek"],
			"73": ["Karen"],
			"99": ["Other non-English languages"],
			"UU": ["Unknown"] };

	return codesTable[code];
}
function homeLanguageSurvey() {
  $j('#CA_PrimaryLanguage').val( '00' );
  if ( $j('#Home_Language_Survey_Date').val() == '' ) {
    $j('#Home_Language_Survey_Date').val('~[eaodate]');
  }
  var languages_chosen = $j(".langlookup").map(function(){
    if ( $j(this).val() && $j(this).val() != '00' ) {
      return $j(this).val(); }
  }).toArray();

  if ( languages_chosen.length == 0 ) {

  } else {
    var modeMap = {},
      maxEl = languages_chosen[0],
      maxCount = 1;

    for(var i = 0; i < languages_chosen.length; i++) {
      var el = languages_chosen[i];
      if (modeMap[el] == null) {
        modeMap[el] = 1;
      } else {
        modeMap[el]++;
      }
      if (modeMap[el] > maxCount) {
        maxEl = el;
        maxCount = modeMap[el];
      }

      else if (modeMap[el] == maxCount) {
        maxEl += '&' + el;
        maxCount = modeMap[el];
      }
    }
    if ( maxEl.indexOf( '&' ) >= 0 ) {
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q12').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q12').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q12').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q11').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q11').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q11').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q10').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q10').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q10').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q9').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q9').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q9').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q8').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q8').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q8').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q7').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q7').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q7').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q6').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q6').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q6').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q5').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q5').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q5').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q4').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q4').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q4').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q3').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q3').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q3').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q2').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q2').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q2').val() ); }
      if ( maxEl.indexOf ( (!!!$j('#HOME_LANGUAGE_SURVEY_Q1').val() ? 'XXXXX' : $j('#HOME_LANGUAGE_SURVEY_Q1').val()) ) >= 0 ) { $j('#CA_PrimaryLanguage').val( $j('#HOME_LANGUAGE_SURVEY_Q1').val() ); }
    } else {
      $j('#CA_PrimaryLanguage').val( maxEl );
    }
  }
  var jobCode = jQuery.trim($j("#CA_PrimaryLanguage").val());
  var jobDesc = primaryLanguageLookup(jobCode);
  $j("#CA_PrimaryLanguage_autocomplete").val(jobDesc);
}
jQuery(document).ready(function () {
  jQuery('.language_list').each(function (o, outer) {
    jQuery(outer).autocomplete({
      source: primaryLanguage,
      focus: function(event, ui) {
        // prevent autocomplete from updating the textbox
        event.preventDefault();
        // manually update the textbox
        jQuery(this).val(ui.item.label);
      },
      select: function(event, ui) {
        // prevent autocomplete from updating the textbox
        event.preventDefault();
        // manually update the textbox and hidden field
        jQuery(this).val(ui.item.label);
        if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q1_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q1').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q5_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q5').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q9_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q9').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q2_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q2').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q6_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q6').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q10_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q10').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q3_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q3').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q7_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q7').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q11_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q11').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q4_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q4').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q8_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q8').val(ui.item.value);
        }
        else if (jQuery(this).attr('id') === 'HOME_LANGUAGE_SURVEY_Q12_autocomplete') {
          jQuery('#HOME_LANGUAGE_SURVEY_Q12').val(ui.item.value);
        }
        homeLanguageSurvey();
      }
    });

  });
  jQuery(".langlookup").each(function() {
	  var fieldVal = jQuery(this).val();
    if (fieldVal != "") {
      try {
        var jobFieldName = jQuery(this).attr("id");
        var jobautocomplete = jobFieldName + "_autocomplete";
        var jobCode = jQuery.trim(jQuery(this).val());
        var jobDesc = primaryLanguageLookup(jobCode);

        jQuery("#" + jobautocomplete).val(jobDesc);
      }
      catch(e) {
        // Do nothing.
      }
    }
  });
});