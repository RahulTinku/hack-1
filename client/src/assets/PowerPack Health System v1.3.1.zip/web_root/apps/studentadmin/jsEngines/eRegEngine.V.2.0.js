//COMMON:  Dictionary Object
var gwDictItems = {};
gwDictItems.yesno = [{"cd":"N","lb":"No"},{"cd":"Y","lb":"Yes"}];
gwDictItems.bit = [{"cd":"0","lb":"No"},{"cd":"1","lb":"Yes"}];
gwDictItems.phonetype = [{"cd":"cell","lb":"Cell"},{"cd":"home","lb":"Home"},{"cd":"work","lb":"Work"}];
gwDictItems.state = [];
gwDictItems.county = [];
gwDictItems.relation = [];
gwDictItems.language = [];
gwDictItems.country = [];

//ADMIN:  JS Objects to hold parent updates on the admin side
var parData = {};
var parReject = {};

//PARENT:  global variables
var locStore;
var dontSaveForm = {};

//COMMON:  Functions to set & retrieve items from the browser's local storage
function gwLocalStorage(gwRecId,gwRecName,gwRecsInAccount)
{
    this.recId = gwRecId;
    this.recname = gwRecName;
    this.today = new Date().getTime();
    this.milliDiff = 7776000000;
    this.dataObj = this.getLocStore();
    this.allRecords = gwRecsInAccount;
}

//get the local storage data for the current user
gwLocalStorage.prototype.getLocStore = function()
{
    if (!localStorageTest())
        return {}

    var tempStore = localStorage.getItem(this.recId); //was this.userId & grabbing all local storage for the specific parent
    var recData = {};

    if(tempStore)
    {
        recData = JSON.parse(tempStore);
        if( recData.recorddate )
        {
            if( this.today - recData.recorddate > this.milliDiff )
                localStorage.removeItem(this.recId);
        }
    }
    return recData;
};


//save the local storage data for the current user
gwLocalStorage.prototype.saveLocStore = function(jsObj)
{
    if (!localStorageTest())
        return

    if( !this.dataObj )
        this.dataObj = {};

    this.dataObj.recorddate = this.today;	//todays date
    this.dataObj.recname = this.recname;	//record name

    if(!this.dataObj.fielddata)				//create field date object for this particular record if it doesn't exist
        this.dataObj.fielddata = {};

    for(var key in jsObj)	//populate the dataObject with field data
        this.dataObj.fielddata[key] = jsObj[key];

    localStorage.setItem(this.recId,JSON.stringify(this.dataObj));
};


//Get an object containing record ids as keys and names as values
gwLocalStorage.prototype.getRecords = function()
{
    var recObj = {};
    for(var z=0;z<this.allRecords.length;z++)
    {
        var rec = this.allRecords[z];
        var tempStore = JSON.parse(localStorage.getItem(rec));

        if( tempStore && tempStore.recorddate )
        {
            if( this.today - tempStore.recorddate < this.milliDiff )
                recObj[rec] = tempStore.recname;
            else
                localStorage.removeItem(rec);
        }
    }
    return recObj;
};


//Return a particular records data fields
gwLocalStorage.prototype.getDataByRecId = function(recId)
{
    var temp = JSON.parse(localStorage.getItem(recId))
    var fd = temp.fielddata;
    return fd;
};


//Is the user's browser modern enought for local storage
function localStorageTest()
{
    var mod = 'modernizr';
    try
    {
        localStorage.setItem(mod, mod);
        localStorage.removeItem(mod);
        return true;
    }
    catch(e)
    {
        $j('#gwFeedback').html("<p>You are unable to use some features of E-Registration with your current browser or browser settings.  Please upgrade your browser to a current version.  If you are running a current version, still seeing this message and want to use the features, disable private browsing and access PowerSchool in a regular browsing window.</p>").show();
        return false;
    }
}
//END COMMON:  Functions to set & retrieve items from the browser's local storage



//COMMON:  function to perform an ajax get call to AjaxRequests.html, which must be in the same directory as the calling page
//	ajaxData:  Parameters in key/value pairs (JSON),  callback:  the name of the callback function used to process results on successful completion
function gwAjaxGet(ajaxData,callback)
{
    $j.ajax({
        type:  'GET'
        , url:  "AjaxRequests.html"
        , cache:  false
        , data:  ajaxData
        , async:   false
        , success:  function(data){ callback(data) }
        , error: function(jqXHR, textStatus, errorThrown){ gwLogIt(errorThrown); }
    });
}

//COMMON:  Initialize the Permissions page
function initalizePermsPage(pName,bDate,eDate)
{
    //load each of the permission form elements
    $j('.parent_name').val( $j.trim($j('#gwGuardName').html()) );
    $j('.effective_date').val(bDate);
    $j('.end_date').val(eDate);
    $j('#gwPageHeader').html(pName + " Permissions");

    //remove the positive radio button if no positive response label exists
    $j('.poslabel').each(function(){
        var gwData = JSON.parse( $j(this).attr('data-gwdata') );
        var permId = gwData.permid;
        if( $j(this).html() == '' || $j(this).html() == '&nbsp;' )
            $j('#posResp_'+permId).remove();
    });

    //remove the negative radio button if no negative response label exists
    $j('.neglabel').each(function(){
        var gwData = JSON.parse( $j(this).attr('data-gwdata') );
        var permId = gwData.permid;
        if( $j(this).html() == '' || $j(this).html() == '&nbsp;' )
            $j('#negResp_'+permId).remove();
    });

    // Change the current setting so it matches one of the response labels
    $j('.gwCurData').each( function(){
        var temp = JSON.parse( $j(this).attr('data-gwdata') );
        var permId = temp.permid;
        if( $j.trim( $j(this).html() ) == 'Y' )
            $j(this).html( $j('#poslabel_'+permId).html() )
        else if( $j.trim( $j(this).html() ) == 'N' )
            $j(this).html( $j('#neglabel_'+permId).html() )
    });
}


//COMMON:  Load dictionary options into selects
function gwLoadDictionaryDD()
{
    $j('.gwDict').each(function()
    {
        if($j(this).attr('data-gwdata'))
        {
            var gwVars = JSON.parse( $j(this).attr('data-gwdata') );
            var optType = "";

            if( "dcode" in gwVars )
                optType = gwVars.dcode;

            if( "dict" in gwVars )  //load dictionary dropdowns
            {
                var fld = $j(this);
                var dictName = gwVars.dict;
                var valType = optType
                var dictOut = "<option value=''></option>";

                for(var i=0; i<gwDictItems[dictName].length; i++)
                {
                    var code = gwDictItems[dictName][i].cd;
                    var label = gwDictItems[dictName][i].lb;

                    if(valType == 'name')
                        dictOut += '<option value="' + label + '">' + label + '</option>';
                    else
                        dictOut += '<option value="' + code + '">' + label + '</option>';
                }
                fld.empty().append(dictOut);

                if( "val" in gwVars )
                    $j(this).val( gwVars.val );
            }
        }
    });
}


//COMMON:  Call this function with a serialized form to save the data
function gwAjaxSave(frmData,usertype)
{
    $j('#gwPageMessage').remove();
    var savePage = "/guardian/gwaea/gwsuccess.html";
    if(usertype == 'admin')
        savePage = "/admin/health/gwsuccess.html";

    var suc = false;
    $j.ajax({
        type:  'POST'
        , url:  savePage
        , cache:  false
        , data:  frmData
        , async:   false
        , success:  function(data)
        {
            if( $j.trim(data) != 'success')
            {
                if( data.indexOf("<h1>Students With Shared Family Information</h1>") >= 0 )
                    suc = true;
                else if( data.indexOf("Validation error for field") >= 0 )
                {
                    $j('#gwSubmit').append( "<div id='gwPageMessage'></div>" );
                    $j('#gwPageMessage').append( $j(data).filter(".box-round") );
                    $j('#btnBack').remove();
                    $j('#gwPageMessage').find("h2").addClass("feedback-alert");
                }
                else
                    gwLogIt(data);
            }
            else
                suc = true;

        }
        , error: function(jqXHR, textStatus, errorThrown){ gwLogIt(errorThrown); }
    });
    return suc;
}


//COMMON:   Field Validation - Required Field
function gwRequired(fld)
{
    var fldId = $j(fld).attr("id");
    var retVal = {"fieldId":fldId, "status":true, "message":""};
    if( !gwHasAValue( fldId ))
    {
        retVal.status = false;
        retVal.message = "You must enter a value in this field.";
    }
    return retVal;
}


// COMMON:  Return true if there is a current value in PowerSchool or the parent has entered an update to the field
function gwHasAValue(fldId)
{
    var newVal = $j.trim($j('#'+fldId).val());

    if( $j('#cur_'+fldId).length )  // this is for a parent in e-Registration
    {
        var curVal = $j.trim($j('#cur_'+fldId).html());

        if( (curVal == '' || curVal == '&nbsp;') && (newVal == '' || newVal == "REMOVE_VALUE") )
            return false;
        else
            return true;
    }

    if( newVal != '' )
        return true;
}


//ADMIN:  Display the parent entered values on the admin approval page
function gwDisplayParentEntry(strData)
{
    for(var key in strData)
    {
        var fName = key;
        var fVal = strData[key];
        var psVal = $j('#'+fName).val();
        var hideField = false;

        if(psVal == '' && fVal == "REMOVE_VALUE")
            hideField = true;

        if( !hideField )
        {
            $j('.'+key).removeClass("gwNoShow");
            var parTB = $j('.'+key).parents('tbody');

            if( $j(parTB).attr("id") ) // remove tbody & header rows
            {
                $j(parTB).children('tr.headerRow').removeClass("gwNoShow");
                $j(parTB).removeClass("gwNoShow");
            }

            if( key.indexOf('race_') > -1 ) //remove race
                $j('.race').removeClass("gwNoShow");
        }

        $j('#par_'+key).html( fVal );  //display the field value in the parent entered data span

        //If current data field is a select, load the select text into the parent entered data span
        if( $j('#'+key).is("select") )
        {
            $j('#'+key + " option").each(function()
            {
                if( fVal == $j.trim( $j(this).val() ) )
                    $j('#par_'+key).html( $j(this).text() );
            });
        }
    }
}


//ADMIN: update acceptance - move the parent data to the PowerSchool fields
function gwMoveUpdates(jsObj)
{
    for(var key in jsObj)
    {
        if( key.indexOf('race_') > -1 )
        {
            var chkRej = $j('#chk_race');
            if( ! $j('#chk_race').attr("checked") )
                $j("input[name='race']").attr("checked",false);
            break;
        }
    }

    for(var key in jsObj)
    {
        var fName = key;
        var fVal = $j.trim(jsObj[key]);
        var rejBox = "";

        if( key.indexOf('race_') > -1 )
            rejBox = "chk_race";
        else
            rejBox = 'chk_'+key;

        if( ! $j('#'+rejBox).attr("checked") ) //Reject change is not checked
        {
            parData[key] = jsObj[key];
            if(fVal == "REMOVE_VALUE") // Parent wants value removed
                $j('#'+key).val("");
            else if( $j('#'+key).length || $j('#'+key).is(':checkbox') ) // the PS exists field is a checkbox
            {
                if( $j('#'+key).is(':checkbox') && jsObj[key] == "Y" ) // the PS field is a checkbox & the parent value is "Y"
                    $j('#'+key).attr("checked",true)	// check the ps checkbox
                else
                    $j('#'+key).val(jsObj[key]);	// move the parent value to the PS field
            }
        }
        else
            parReject[key] = jsObj[key];
    }
}


//ADMIN:  Toggle the save button & the processing image
function gwToggleSave(togAct)
{
    if(togAct == 'off')
    {
        $j('#gwSubmitBtn').hide();
        $j('#gwProcessPict').show();
    }
    else
    {
        $j('#gwSubmitBtn').show();
        $j('#gwProcessPict').hide();
    }
}


//ADMIN: Accept demographic updates
function gwAcceptUpdates()
{
    if( $j('#guardian_entered_data').val() != '')
        gwMoveUpdates( JSON.parse( $j('#guardian_entered_data').val() ));

    $j('#gwSubmit').addClass("feedback-note");
    $j('#gwSaveMsg').html("Acceptance task has been completed. Click the Save button to save updates.");
    $j('#gwAccept').hide();
    $j('#gwSubmit').show();
}


//ADMIN:  Save demographic updates
function gwSaveUpdates()
{
    $j('#gwSubmit').removeClass("feedback-note");
    $j('#gwSaveBtn').hide();
    $j('#gwProcessPict').show();

    var saveSuccess = true;

    //save the updates
    var stuUpdates = $j('#gwStudentData').serialize();
    saveSuccess = gwAjaxSave(stuUpdates,'admin');

    if( !saveSuccess )
    {
        $j('#gwSubmit').removeClass("feedback-alert");
        $j('#gwSaveMsg').html("An error has occured while saving student data.");
        $j('#gwSaveBtn').show();
        $j('#gwProcessPict').hide();
        return;
    }

    //Update the archive table
    $j('#arc_guardian_ip').val( $j('#guardian_ip').val() );
    $j('#arc_guardian_completed_date').val( $j('#guardian_completed_date').val() );
    $j('#arc_guardian_name').val( $j('#guardian_name').val() );
    $j('#arc_staff_approved_date').val( today );

    var strParData = JSON.stringify(parData);
    var strRejData = JSON.stringify(parReject);

    if( strParData.length > 2 )
        $j('#arc_guardian_entered_data').val( strParData );  //guardian_entered_data

    if( strRejData.length > 2 )
        $j('#arc_rejected_data').val( strRejData );  //rejected data

    var arcRec = $j('#gwRecordArchive').serialize();
    saveSuccess = gwAjaxSave(arcRec,'admin');


    //Update the "current" table.  Clear parent entered values, set approved flag & date.
    $j('#staff_approved').val('1');
    $j('#staff_approved_date').val(today);
    $j('#guardian_entered_data').val('');
    var curRec = $j('#gwParentUpdate').serialize();
    saveSuccess = gwAjaxSave(curRec,'admin');

    //finalize the save process
    $j('#gwSubmit').addClass("feedback-confirm");
    $j('#gwSaveMsg').html("The student updates have been saved.");
    //$j('#gwSaveBtn').show();
    $j('#gwProcessPict').hide();
}


//ADMIN: Initialize the data approval page
function gwInitDemogApproval()
{
    gwLoadDictionaryDD();

    if( $j('#guardian_entered_data').val() != '')
        gwDisplayParentEntry( JSON.parse( $j('#guardian_entered_data').val() ));

    $j('.gwNoShow').remove();
}


//ADMIN:  DICTIONARY CREATE/EDIT FUNCTIONS
function gwSaveDict()
{
    $j('#gwSaveMsg').html("").removeClass("feedback-alert");
    var doSave = true;
    //$j('#newCode').val( $j('#newCode').val().toLowerCase() );
    var iCode = $j('#newCode').val();
    var iLabel = $j('#newDesc').val();
    var iType = $j('#dictType').val();

    if( iCode == '' || iLabel == '')
    {
        $j('#gwSaveMsg').html("You must enter a code and description for the dictionary item").addClass("feedback-alert");
        doSave = false;
        return;
    }

    $j('.'+iType).each( function(){
        $j(this).find(".item_code").each( function(index,fld)
        {
            var tempVal = $j(fld).val();
            if( tempVal == iCode )
            {
                $j('#gwSaveMsg').html("The code you have entered already exists.  Please try another code.").addClass("feedback-alert");
                doSave = false;
                return;
            }
        });

        $j(this).find(".item_label").each( function(index,fld)
        {
            var tempVal = $j(fld).val();
            if( tempVal == iLabel )
            {
                $j('#gwSaveMsg').html("The Description you have entered already exists.  Please try another description.").addClass("feedback-alert");
                doSave = false;
                return;
            }
        });
    });

    if( ! doSave )
        return false;

    var myForm = $j("#gwDict").serialize();
    var saveSuccess = gwAjaxSave(myForm,'admin');

    if( saveSuccess )
    {
        $j('#gwSaveMsg').html("Saved").addClass("feedback-confirm");
        var newRow = "<tr class=\"dictitem "+$j('#itemType').val()+"\"><td></td>";
        newRow += "<td>"+$j('#newCode').val()+"</td>";
        newRow += "<td>"+$j('#newDesc').val()+"</td>";

        if( $j('#newOrder').length )
            newRow += "<td>"+$j('#newOrder').val()+"</td>";

        newRow += "<td>Yes</td>";

        if( $j('#newOther').length )
            newRow += "<td>"+$j('#newOther').val()+"</td>";

        newRow += "</tr>";
        $j('#dictTable').append(newRow);
        $j('#newCode').val("");
        $j('#newDesc').val("");
        if( $j('#newOther').length ) $j('#newOrder').val("");
        if( $j('#newOther').length ) $j('#newOther').val("");
        setTimeout(function(){$j('#gwSaveMsg').html("").removeClass("feedback-confirm")}, 3000);
    }
}

function gwShowDicts(fld)
{
    var dItem = $j(fld).val();
    $j('#dictType').val(dItem);
    $j('#itemType').val(dItem);
    $j('.dictitem').addClass('gwNoShow');
    $j('.'+dItem).removeClass('gwNoShow');
}

function gwEditDict(itemId)
{
    $j('#editId').val(itemId);
    $j('#editType').val( $j('#type_'+itemId).val() ).attr('name',$j('#type_'+itemId).attr('name') );
    $j('#editCode').val( $j('#code_'+itemId).val() ).attr('name',$j('#code_'+itemId).attr('name') );
    $j('#editLabel').val( $j('#label_'+itemId).val() ).attr('name',$j('#label_'+itemId).attr('name') );
    $j('#editDisplay').val( $j('#display_'+itemId).val() ).attr('name',$j('#display_'+itemId).attr('name') );
    $j('#editActive').val( $j('#active_'+itemId).val() ).attr('name',$j('#active_'+itemId).attr('name') );

    if( $j('#editOther').length )
        $j('#editOther').val( $j('#other_'+itemId).val() ).attr('name',$j('#other_'+itemId).attr('name') );

    $j( "#gwEditDialog" ).dialog( "open" );

}

function gwSaveDictUpdate()
{
    var myForm = $j("#gwFrmEditDict").serialize();
    var saveSuccess = gwAjaxSave(myForm,'admin');
    var itemId = $j('#editId').val();

    if(saveSuccess)
    {
        $j('#code_'+itemId).val( $j('#editCode').val() );
        $j('#label_'+itemId).val( $j('#editLabel').val() );
        $j('#display_'+itemId).val( $j('#editDisplay').val() );
        $j('#active_'+itemId).val( $j('#editActive option:selected').text() );

        if( $j('#other_'+itemId).length )
            $j('#other_'+itemId).val( $j('#editOther').val() );

        $j( "#gwEditDialog" ).dialog( "close" );
    }
}
//ADMIN:  END OF DICTIONARY FUNCTIONS


//PARENT:  initialize parent screens
function gwInitializePage(approved,completed)
{
    var gwDoLocStor = 0;

    //load dictionary drop downs
    gwLoadDictionaryDD();

    //Set widths on entry table
    $j('.gwParTable td:nth-child(1)').addClass('gwLabel');
    $j('.gwParTable td:nth-child(2)').addClass('gwCur');

    //determine where the user lands after form submission
    $j('#gwDataForm').attr("action",gwNextTab);

    //Prepare the parent data entry fields.  Loop through every gwParInput fields on the page
    $j('.gwParInput').each(function()
    {
        if($j(this).attr('data-gwdata'))
        {
            var gwVars = JSON.parse( $j(this).attr('data-gwdata') );

            if( "vld" in gwVars )  //load validation events
                $j(this).blur( function(){ gwFieldValidate($j(this));});

            if( gwDoLocStor == 0 )  //copy data between students functionality has not yet been tripped
            {
                if( "copyb" in gwVars )  //check for fields that can be copied between students
                    gwDoLocStor = 1;
            }
        };

        $j(this).focus(function() { $j(this).parent().parent().addClass('gwCurrentRow'); });	//change row background color
        $j(this).blur(function() { $j(this).parent().parent().removeClass('gwCurrentRow'); });	// remove row background color
        $j(this).closest('td').addClass("gwInputTD"); // add the gwInputTD class to the parent table cell of each input field
    });

    //Add an onclick to cells with the gwDelete class
    $j('.gwDelete').each(function(){ $j(this).attr('title','Remove Value From PowerSchool'); $j(this).click(function(){gwParentRemove($j(this));}); });

    // Prepare the current data display
    gwSetCurDataDisplay();

    //load previously entered data
    if( $j('#guardian_entered_data').val() != '')
        gwLoadFieldValues( JSON.parse( $j('#guardian_entered_data').val() ));

    //get All students currently in the guardian's account
    var gwAllKids = new Array();
    $j('#students-list li').not('.selected').each( function(){
        var theText = $j(this).attr("data-gwId");
        gwAllKids.push(theText);
    });

    //begin local storage process
    locStore = new gwLocalStorage(gwCurStuId,gwCurStuFirst,gwAllKids);

    if( gwDoLocStor == 1 ) //if any fields on page are marked as copyb, then show the copy from other student dialog
        gwBuildCopyFromList(locStore.getRecords());
}


//PARENT:  Student data copy dialog
function gwBuildCopyFromList(stuObj)
{
    var numStuWithData = 0;
    $j('#gwLocStuList').empty()
    for(var key in stuObj)
    {
        if(key != gwCurStuId)
        {
            numStuWithData++;
            var temp = "<span class='gwLocStuList'><input type='button' value='"+stuObj[key]+"' onclick='gwCopyFromStudent(\""+key+"\");' class='gwLocStoreButton'/></span>";
            $j('#gwLocStuList').append(temp);
        }
    }

    if(numStuWithData>0)
    {
        $j("#gwFeedback").addClass('feedback-note').show();
        $j('#eReg').change(function(){ $j('#gwFeedback').hide().removeClass('feedback-note').html(""); });
    }

}

//PARENT:  Expand the 3rd & 4th Parent contacts if required on parents page
function gwInitializeExtraContacts()
{
    if( gwHasAValue('cnt3_fname') )
    {
        $j('#p3Question').hide();
        $j('#parent3').show();
    }

    if( gwHasAValue('cnt4_fname') )
    {
        $j('#p4Question').hide();
        $j('#parent4').show();
    }
}

//PARENT:  copy data from 1 student to another
function gwCopyFromStudent(stuId)
{
    var stuObj = locStore.getDataByRecId(stuId);
    gwLoadFieldValues( stuObj );
    $j('#gwFeedback').hide().removeClass('feedback-note').html("");

    if( $j('#cnt3_fname').length )
        gwInitializeExtraContacts();

    if( $j('#cnt4_fname').length )
        gwInitializeExtraContacts();

    return true;
}


//PARENT:  SHOW PREVIOUSLY ENTERED VALUES
function gwLoadFieldValues(jsObj)
{
    for(var key in jsObj)
    {
        if( $j('#'+key).length || $j('#'+key).is(':checkbox') )
        {
            if( $j('#'+key).is(':checkbox') && jsObj[key] == "Y" )
                $j('#'+key).attr("checked",true)
            else
                $j('#'+key).val(jsObj[key]);
        }
    }
}


//PARENT:  Set the display values in the gwCurData spans
function gwSetCurDataDisplay()
{
    $j('.gwCurData').each(function()
    {
        var curId =  $j(this).attr('id');
        var pId = curId.slice(curId.indexOf("_")+1);
        if( $j('#'+pId).is("select") )
        {
            $j('#'+pId + " option").each(function()
            {
                if( $j.trim( $j('#'+curId).html() ) == $j.trim( $j(this).val() ) )
                    $j('#'+curId).html( $j(this).text() );
            });
        }
    });
}


//PARENT:  Normalize field values if they have a space or are blank
function gwFieldValNorm(fldVal,defaultVal)
{
    var retVal = "";
    var theVal = $j.trim(fldVal);
    if(	theVal == "&nbsp;" || theVal == "" )
        retVal = defaultVal;
    else
        retVal = theVal;

    return retVal;
}


//PARENT:  Gather the parent entered data & submit the form
function gwParentFormSubmit()
{
    var parDataOne = {};
    var parDataTwo = {};
    var fieldErrors = 0;

    $j('#gwSubmitBtn').hide();
    $j('#gwProcessPict').show();

    $j('.gwParInput').each(function()
    {
        if( !gwFieldValidate($j(this)) )
        {
            fieldErrors++;
            gwLogIt("Field Error:  "+$j(this).attr('id'));
        }
    });

    if(fieldErrors > 0)
    {
        $j('#gwSaveMsg').html("1 or more problems have been detected with the data you have entered.  Please address these issues and try to save again.");
        $j('#gwSaveMsg').addClass("gwFieldMsg");
        $j('#gwSubmitBtn').show();
        $j('#gwProcessPict').hide();
        return false;
    }

    if( $j.trim( $j('#guardian_entered_data').val() ) != '')
        parDataOne = JSON.parse( $j('#guardian_entered_data').val() );

    parDataOne = gwRemoveParentValues(parDataOne);
    $j('#guardian_entered_data').val(gwGatherParentValues(parDataOne)); //save entered values into first parent data field
    $j('#staff_approved').val('0');  //On save, set Approved='0'
    var toLocStore = gwFieldsToLocStore();
    locStore.saveLocStore(toLocStore);
    document.getElementById("gwDataForm").submit();
}


//PARENT:  Save data to localStorage variables
function gwFieldsToLocStore()
{
    var objLoc = {};

    $j('.gwParInput').each(function() {

        if($j(this).attr('data-gwdata'))
        {
            var gwVars = JSON.parse( $j(this).attr('data-gwdata') );

            if( "copyb" in gwVars && gwVars.copyb == 'Y' )  //data should be saved for copying between students
            {
                if( $j(this).is(":checkbox") && $j(this).attr("checked") )
                    objLoc[$j(this).attr('id')] = "Y";
                else if( $j.trim( $j(this).val() ) != '' )
                    objLoc[$j(this).attr('id')] = $j(this).val();
            }
        }
    });
    return objLoc;
}


//PARENT:  Go through all fields with the .gwParInput class, grab any entered values & store them in a JSON object, return the JSON Object
function gwGatherParentValues(jsObj)
{
    // get values from any field gwParInput field with a value
    $j('.gwParInput').each(function() {
        if( $j(this).is(":checkbox") && $j(this).attr("checked") )
            jsObj[$j(this).attr('id')] = "Y";
        else if( $j.trim( $j(this).val() ) != '' )
            jsObj[$j(this).attr('id')] =  $j.trim( $j(this).val() );
    });

    return JSON.stringify(jsObj);
}


//PARENT:  if element exists on page, but doesn't have a value any longer, remove it from the object
function gwRemoveParentValues(jsObj)
{
    for(var key in jsObj)
    {
        if( $j('#'+key).length || $j('#'+key).is(':checkbox') )
        {
            if( ($j('#'+key).is(":checkbox") && !$j('#'+key).attr("checked")) || $j.trim( $j('#'+key).val() ) == '' ) //is it a checkbox & unchecked or has no value
                delete jsObj[key]
        }
    }

    return jsObj;
}


//PARENT:  remove a single field value
function gwParentRemove(fld)
{
    var tblRow = fld.parent();
    $j(tblRow).find(".gwParInput").each(function (){ gwSetToRemove($j(this)); });
}


//PARENT:  remove values from a group of fields within a <tbody> tag
function gwRemoveGroup(tbodyId)
{
    $j('#'+tbodyId).find(".gwParInput").each(function (){ gwSetToRemove($j(this)); });
}


//PARENT: perform the actual value removal
function gwSetToRemove(fld)
{
    if( $j(fld).is("select") )
    {
        if(! $j(fld).find(" option[value='REMOVE_VALUE']").length > 0)
            $j(fld).append($j("<option></option>").attr("value","REMOVE_VALUE").text("REMOVE_VALUE"));
    }
    $j(fld).val("REMOVE_VALUE");
}


//PARENT:  load field values
/*
 function gwDataToFields(dataObj)
 {
 for(var key in dataObj.fielddata)
 {
 $j('#'+key).val( dataObj.fielddata[key] );
 }
 } */


//PARENT: copy physical address to mailing address
function copyAddress()
{
    $j("#mailing_street").val( $j("#street").val() );
    $j("#mailing_city").val( $j("#city").val() );
    $j("#mailing_state").val( $j("#state").val() );
    $j("#mailing_zip").val( $j("#zip").val() );
}


//PARENT:  Disable any tabs that the user shouldn't be allowed to click on
function gwDisableTabs()
{
    $j('#gwNavTabs li.selected').nextAll().each( function(){
        var theText = "<span class='gwDeadTab'>" + $j(this).children("a").text() + "<span>";
        $j(this).children("a").remove();
        $j(this).html(theText);
        $j(this).css( "background-color", "red" );
    });
}


//PARENT:  save updates to the native PowerSchool health fields
function gwSaveNativeHealth()
{
    var pData = {};
    if( $j.trim($j('#guardian_entered_data').val()) != '' )
        pData = JSON.parse( $j('#guardian_entered_data').val() );

    if( $j.trim($j('#medical_considerations').val()) != "" )
        pData.medical_considerations = $j.trim($j('#medical_considerations').val());

    if( $j.trim($j('#allergies').val()) != "" )
        pData.allergies = $j.trim($j('#allergies').val());

    if( $j.trim($j('#medical_considerations').val()) != "" || $j.trim($j('#allergies').val()) != "")
    {
        $j('#guardian_entered_data').val( JSON.stringify(pData) );
        $j('#staff_approved').val("0");
    }
    else
    {
        dontSaveForm.gwnative = false;
    }

    return true;
}


//PARENT:  loop through all forms with class "healthform" and save their data
function gwHealthFormSubmit()
{
    $j('#guardian_progress').val('health');
    $j('#gwSaveMsg').hide();
    gwToggleSave('off');
    var saveSuccess = true;

    var doSub = true;
    $j('.healthform').each( function()
    {
        var onSub = $j(this).attr('onsubmit');

        if(!onSub)
            onSub = $j(this).attr('data-onsubmit');

        if(onSub)
            doSub = eval(onSub)
    });

    if(doSub)
    {
        $j('.healthform').each( function()
        {
            var frmId = $j(this).attr("id");
            if( !dontSaveForm.hasOwnProperty(frmId) )
            {
                var frmData = $j(this).serialize();
                saveSuccess = gwAjaxSave(frmData,'parent');
            }
        });

        if(saveSuccess)
            location.href = gwNextTab;
        else
        {
            $j('#gwSaveMsg').html(" An error occurred while saving your entries.  Please try saving again.  If the error continues, contact your child's school");
            $j('#gwSaveMsg').addClass("feedback-alert").show();
        }
    }
    else
    {
        $j('#gwSaveMsg').html(" An error occurred while validating your entries.  Please double check the values you have entered.");
        $j('#gwSaveMsg').addClass("gwFieldMsg").show();
        gwToggleSave('on');
    }
}




