function getCCIds($table) {
    var CCIDList = [];
    jQuery($table.children('tbody').find('tr.studentrow')).each(function () {
        CCIDList.push(this.id.split('_')[1]);
    });
    return String(CCIDList);
};

function getStatus(CCIDList, URL) {
    return jQuery.getJSON(URL, {
        CCIDList: CCIDList
    });
};