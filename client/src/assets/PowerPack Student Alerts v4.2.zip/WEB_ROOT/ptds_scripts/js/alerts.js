function setDefaultValues()
{
    if(jQuery('#ell-date').val()=='')
    {
        console.log('Resetted Ell');
        jQuery('#ell-date').val('0/0/0');
    }
    if(jQuery('#504-date').val()=='')
    {
        console.log('Re0-set 504');
        jQuery('#504-date').val('0/0/0');
    }
    if(jQuery('#IEP-date').val()=='')
    {
        console.log('Reset IEP');
        jQuery('#IEP-date').val('0/0/0');
    }
    if(jQuery('#sped-date').val()=='')
    {
        console.log('Reset SPED');
        jQuery('#sped-date').val('0/0/0');
    }
    if(jQuery('#cust-date').val()=='')
    {
        console.log('Reset CUST');
        jQuery('#cust-date').val('0/0/0');
    }
    return true;
}